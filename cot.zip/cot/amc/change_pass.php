<?php
	include "header.php";
    $qry1="SELECT * FROM tbl_login WHERE l_id='$id'";
    $run1=mysqli_query($con,$qry1);
    $result1=mysqli_fetch_array($run1);
    $l_pass=$result1['l_pass'];
?>
 <div class="pcoded-content">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                            <h5 class="m-b-10">Change Password</h5>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="dashboard.php"> <i class="fa fa-home"></i> </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="#!">Change Password</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Page-header end -->
<div class="pcoded-inner-content">
                            <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
			<div class="page-body">
               <div class="row">
                     <div class="col-md-12">
                        <div class="card">
                          <div class="card-header">
                            <h5>Change Password</h5>
                                                        <!--<span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>-->
                          </div>
                          <div class="card-block">
                                                        <form method="POST" action="" class="form-material">
                                                            <div class="form-group form-default form-static-label">
                                                                <input type="password" name="pass" class="form-control" placeholder="Enter Old Password" required>
                                                                <span class="form-bar"></span>
                                                                <label class="float-label">Old Password</label>
                                                            </div>
                                                            <div class="form-group form-default form-static-label">
                                                                <input type="password" name="pass1" class="form-control" placeholder="Enter New Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                                                                <span class="form-bar"></span>
                                                                <label class="float-label">New Password</label>
                                                            </div>
                                                           <div class="form-group form-default form-static-label">
                                                                <input type="password" name="pass2" class="form-control" placeholder="Confirm New Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                                                                <span class="form-bar"></span>
                                                                <label class="float-label">Confirm Password</label>
                                                            </div>
                                                        
                                                            <div class="form-group form-default form-static-label">
                                                            <button type="submit" name="submit" class="btn btn-primary waves-effect waves-light">Add</button>
                                                        </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>        
               </div>
           </div>
       </div>
   </div>
</div>

<?php
	include "footer.php";
    if(isset($_POST['submit']))
    {
        $pass=$_POST['pass'];   
        $pass1=$_POST['pass1'];
        $pass2=$_POST['pass2'];
        if($l_pass==$pass)
        {
            if($pass1==$pass2)
            {
                $qry1="UPDATE tbl_login SET l_pass='$pass2' WHERE l_id='$id'";
                $run1=mysqli_query($con,$qry1);
                if($run1)
                {
                    echo "<script> alert('Password Changed'); </script>";
                    echo "<script> location.replace('dashboard.php'); </script>";    
                }
            }
            else
            {
                echo "<script> alert('Both the Passwords are Different'); </script>";
                echo "<script> location.replace('change_pass.php'); </script>";
            }
        }
        else
        {
            echo "<script> alert('Incorrect Old Password'); </script>";
            echo "<script> location.replace('change_pass.php'); </script>";
        }

    }
?>