<?php
	include "header.php";
?>
 <div class="pcoded-content">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                            <h5 class="m-b-10">Edit Profile</h5>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="dashboard.php"> <i class="fa fa-home"></i> </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="#!"> Edit Profile</a>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Page-header end -->
<div class="pcoded-inner-content">
                            <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
			<div class="page-body">
               <div class="row">
                     <div class="col-md-12">
                        <div class="card">
                          <div class="card-header">
                            <h5>Edit Profile</h5>
                                                        <!--<span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>-->
                          </div>
                          <div class="card-block">
                                                        <form method="POST" action="" class="form-material">
                                                            <div class="form-group form-default form-static-label">
                                                                <input type="text" name="name" class="form-control" value="<?php echo $name; ?>" required>
                                                                <span class="form-bar"></span>
                                                                <label class="float-label">Name</label>
                                                            </div>
                                                            <div class="form-group form-default form-static-label">
                                                                <input type="text" name="email" class="form-control" value="<?php echo $email; ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
                                                                <span class="form-bar"></span>
                                                                <label class="float-label">Email</label>
                                                            </div>
                                                            <div class="form-group form-default form-static-label">
                                                                <input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>" required>
                                                                <span class="form-bar"></span>
                                                                <label class="float-label">Phone Number</label>
                                                            </div>

                                                            <div class="form-group form-default form-static-label">
                                                            <textarea rows="3" class="form-control" name="add" required><?php echo $add; ?></textarea>
                                                            <span class="form-bar"></span>
                                                                <label class="float-label">Address</label>
                                                        </div>
                                                        <div class="form-group form-default form-static-label">
                                                            <input type="file" class="form-control" name="image">
                                                            <span class="form-bar"></span>
                                                                <label class="float-label">Upload New DP</label>
                                                        </div>
                                                        <div class="form-group form-default form-static-label">
                                                            <img src="<?php echo $img; ?>" height="120px" width="120px" style="margin-top: 3%;">
                                                            <span class="form-bar"></span>
                                                                <label class="float-label">Current DP</label>
                                                        </div>
                                                        
                                                            <div class="form-group form-default form-static-label">
                                                            <button class="btn btn-primary waves-effect waves-light" name="submit">Add</button>
                                                        </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>        
               </div>
           </div>
       </div>
   </div>
</div>

<?php
	include "footer.php";
    if(isset($_POST['submit']))
    {

        $name=$_POST['name'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
        $add=$_POST['add'];
        $image=$_POST['image'];
        //echo "Hello".$image;
        if($image=="")
        {
            $qry1="UPDATE tbl_login SET l_email='$email', l_name='$name', l_phone='$phone', l_add='$add' WHERE l_id='$id'";
            $run1=mysqli_query($con,$qry1);
            if($run1)
            {
                echo "<script> alert('Profile Updated'); </script>";
                echo "<script> location.replace('dashboard.php'); </script>";    
            }
            else
            {
                echo "<script> alert('Profile Not Updated'); </script>";
                echo "<script> location.replace('edit_profile.php'); </script>";    
            }
        }
        else
        {
            $location="photos/".$image;
            $qry1="UPDATE tbl_login SET l_email='$email', l_name='$name', l_phone='$phone', l_add='$add', l_img='$location' WHERE l_id='$id'";
            $run1=mysqli_query($con,$qry1);
            if($run1)
            {
                echo "<script> alert('Profile Updated'); </script>";
                echo "<script> location.replace('dashboard.php'); </script>";    
            }
            else
            {
                echo "<script> alert('Profile Not Updated'); </script>";
                echo "<script> location.replace('edit_profile.php'); </script>";    
            }   
        }

    }
?>