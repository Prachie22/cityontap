<?php
	include "header.php";
     if(isset($_GET['id']))
       {
        $c_id=$_GET['id']."";
      //echo "<script>alert('$d_id');</script>";
       }
?>
 <div class="pcoded-content">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                            <h5 class="m-b-10">Update Status</h5>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="dashboard.php"> <i class="fa fa-home"></i> </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="#!"> View Complain</a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="#!">Update Status</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Page-header end -->
<div class="pcoded-inner-content">
                            <!-- Main-body start -->
    <div class="main-body">
        <div class="page-wrapper">
			<div class="page-body">
               <div class="row">
                     <div class="col-md-12">
                        <div class="card">
                          <div class="card-header">
                            <h5>Update Status</h5>
                                                        <!--<span>Add class of <code>.form-control</code> with <code>&lt;input&gt;</code> tag</span>-->
                          </div>
                          <div class="card-block">
                                                        <form method="POST" action="" class="form-material">
                                                           
                                                            <div class="form-group form-default form-static-label">
                                                                <select class="form-control" name="status">
                                                                    <option value="1">Not Solved</option>
                                                                    <option value="2">Solved</option>
                                                                </select>
                                                                <span class="form-bar"></span>
                                                                <label class="float-label">Update Complain Status</label>
                                                            </div>
                                                           
                                                        
                                                            <div class="form-group form-default form-static-label">
                                                            <button type="submit" name="submit" class="btn btn-primary waves-effect waves-light">Add</button>
                                                        </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>        
               </div>
           </div>
       </div>
   </div>
</div>

<?php
	include "footer.php";
    if(isset($_POST['submit']))
    {
        $status=$_POST['status'];
        $qry1="INSERT INTO tbl_complain_status(cs_id,l_id,c_id)VALUES('','$id','$c_id')";
        $run1=mysqli_query($con,$qry1);

        $qry2="UPDATE tbl_complain SET c_status='2' WHERE c_id='$c_id'";
        $run2=mysqli_query($con,$qry2);
        if($run2)
        {
            echo ("<script>location.href='view_solved_complain.php'</script>");
        }
        else
        {
            echo "<script>alert('Not Solved'); </script>";
            echo ("<script>location.href='view_complain.php'</script>");
        }
    }
?>