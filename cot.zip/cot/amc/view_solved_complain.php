<?php
	include 'header.php';
?>
	<div class="pcoded-content">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                            <h5 class="m-b-10">View Solved Complain</h5>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="dashboard.php"> <i class="fa fa-home"></i> </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="#!">Complain</a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="#!">View Solved Complain</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Page-header end -->
                        <div class="pcoded-inner-content">
                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <!-- Page-body start -->
                                    <div class="page-body">
                                        <!-- Basic table card start -->
                                        
                                        <div class="card">
                                            <div class="card-header">
                                                <h5>View Solved Complain</h5>
                                                <div class="card-header-right">
                                                    <ul class="list-unstyled card-option">
                                                        <li><i class="fa fa fa-wrench open-card-option"></i></li>
                                                        <li><i class="fa fa-window-maximize full-card"></i></li>
                                                        <li><i class="fa fa-minus minimize-card"></i></li>
                                                        <li><i class="fa fa-refresh reload-card"></i></li>
                                                        <li><i class="fa fa-trash close-card"></i></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-block table-border-style">
                                                <div class="table-responsive">
                                                    <table class="table table-hover">
                                                        <thead>
                                                            <tr>
                                                                <th>Sr</th>
                                                                <th>Name</th>
                                                                <th>Email</th>
                                                                <th>Phone</th>
                                                                <th>Complain</th>
                                                                <th>Time</th>
                                                                <th>Image</th>
                                                                <th>Place Details</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php
                                                        $seq=1;
                                                        $qry1="SELECT * FROM tbl_complain_status WHERE l_id='$id'";
                                                        $run1=mysqli_query($con,$qry1);
                                                    	while($result1=mysqli_fetch_array($run1))
                                                    	{
                                                            $c_id=$result1['c_id'];
                                                            
                                                            //$l_id=$result1['l_id'];
                                                            $qry2="SELECT * FROM tbl_complain WHERE c_id='$c_id'";
                                                            $run2=mysqli_query($con,$qry2);
                                                            $result2=mysqli_fetch_array($run2);
                                                            $user_id=$result2['l_id'];
                                                            $p_id=$result2['p_id'];
                                                            $qry3="SELECT * FROM tbl_login WHERE l_id='$user_id'";
                                                            $run3=mysqli_query($con,$qry3);
                                                            $result3=mysqli_fetch_array($run3);
                                                        ?>
                                                            <tr>
                                                                <th scope="row"><?php echo $seq; ?></th>
                                                                <td><?php echo $result3['l_name']; ?></td>
                                                                <td><?php echo $result3['l_email']; ?></td>
                                                                <td><?php echo $result3['l_phone']; ?></td>
                                                                <td class="p"><?php echo $result2['complain']; ?></td>
                                                                <td><?php echo $result2['c_time']; ?></td>
                                                                <td><img src="<?php echo $result3['l_img']; ?>" width="60px" height="60px"></td>
                                                                <td><a href="view_place.php?id=<?php echo $p_id; ?>"  class="btn btn-success waves-effect waves-light">View</a></td>
                                                                 
                                                                
                                                            </tr>
                                                        <?php
                                                        	$seq++;
                                                        }
                                                        
                                                        ?>    
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Hover table card end -->
                                        <!-- Contextual classes table starts -->
<?php
	include "footer.php";
?>