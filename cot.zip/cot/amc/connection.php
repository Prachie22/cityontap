<?php
	
	$con = mysqli_connect('localhost','root','','city');
	
	if(!$con)
	{
		echo "Server not found...";
	}else{mysqli_select_db($con,'city');}	
	/*
	if(!mysqli_select_db($con,'lawyer'))
	{
		echo "Database not found...";
	}*/

?>