<?php
    include 'header.php';
    if(isset($_GET['id']))
       {
        $p_id=$_GET['id']."";
      //echo "<script>alert('$d_id');</script>";
       }
?>
    <div class="pcoded-content">
                        <!-- Page-header start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="page-header-title">
                                            <h5 class="m-b-10">Manage Place</h5>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="dashboard.php"> <i class="fa fa-home"></i> </a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="#!">View Complain</a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="#!">Manage Place</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Page-header end -->
                        <div class="pcoded-inner-content">
                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <!-- Page-body start -->
                                    <div class="page-body">
                                        <!-- Basic table card start -->
                                        
                                        <div class="card">
                                            <div class="card-header">
                                                <h5>Manage Place</h5>
                                                <div class="card-header-right">
                                                    <ul class="list-unstyled card-option">
                                                        <li><i class="fa fa fa-wrench open-card-option"></i></li>
                                                        <li><i class="fa fa-window-maximize full-card"></i></li>
                                                        <li><i class="fa fa-minus minimize-card"></i></li>
                                                        <li><i class="fa fa-refresh reload-card"></i></li>
                                                        <li><i class="fa fa-trash close-card"></i></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-block table-border-style">
                                                <div class="table-responsive">
                                                    <table class="table table-hover">
                                                        <thead>
                                                            <tr>
                                                                <th>Sr</th>
                                                                <th>Name</th>
                                                                <th>Timings</th>
                                                                <th>Open Days</th>
                                                                <th>Website</th>
                                                                <th>Address</th>
                                                                <th>Category</th>
                                                                <th>Images</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php
                                                        $seq=1;
                                                        $qry1="SELECT * FROM tbl_place WHERE p_id='$p_id'";
                                                        $run1=mysqli_query($con,$qry1);
                                                        while($result1=mysqli_fetch_array($run1))
                                                        {
                                                            $p_id=$result1['p_id'];
                                                            $cat_id=$result1['cat_id'];
                                                            $qry2="SELECT * FROM tbl_category WHERE cat_id='$cat_id'";
                                                            $run2=mysqli_query($con,$qry2);
                                                            $result2=mysqli_fetch_array($run2);
                                                        ?>
                                                            <tr>
                                                                <th scope="row"><?php echo $seq; ?></th>
                                                                <td><?php echo $result1['p_name']; ?></td>
                                                                <td><?php echo $result1['p_start_time']; ?><br/>
                                                                    <?php echo $result1['p_end_time']; ?>
                                                                </td>
                                                                <td><?php echo $result1['p_open_days']; ?></td>
                                                                
                                                                <td><?php echo $result1['p_website']; ?></td>
                                                                <td class="p"><?php echo $result1['p_add']; ?></td>
                                                                <td><?php echo $result2['category']; ?></td>
                                                                <td><a href="view_place_img.php?id=<?php echo $p_id; ?>"  class="btn btn-success waves-effect waves-light">View</a></td>
                                                            </tr>
                                                        <?php
                                                            $seq++;
                                                        }
                                                        
                                                        ?>    
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Hover table card end -->
                                        <!-- Contextual classes table starts -->
<?php
    include "footer.php";
?>