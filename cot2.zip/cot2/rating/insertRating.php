<?php
require_once ('db.php');
$status='1';
// Here the user id is harcoded.
// You can integrate your authentication code here to get the logged in user id
if(isset($_GET['id']))
       {
        $userId=$_GET['id']."";
      //echo "<script>alert('$d_id');</script>";
       }


if (isset($_POST["index"], $_POST["p_id"])) {
    
    $restaurantId = $_POST["p_id"];
    $rating = $_POST["index"];
    
    $checkIfExistQuery = "select * from tbl_rating where l_id = '" . $userId . "' and p_id = '" . $restaurantId . "'";
    if ($result = mysqli_query($conn, $checkIfExistQuery)) {
        $rowcount = mysqli_num_rows($result);
    }
    
    if ($rowcount == 0) {
        
        $insertQuery = "INSERT INTO tbl_rating(l_id,p_id, rating,r_status) VALUES ('" . $userId . "','" . $restaurantId . "','" . $rating . "','" . $status . "') ";
        $result = mysqli_query($conn, $insertQuery);
        //header("location:../admin/dashboard.php");
        
    } else {
        echo "Already Voted!";
    }
}
