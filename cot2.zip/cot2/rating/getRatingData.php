<?php
require_once "db.php";
require_once "functions.php";
// Here the user id is harcoded.
// You can integrate your authentication code here to get the logged in user id
$userId = 1;

$query = "SELECT * FROM tbl_place ORDER BY p_id DESC";
$result = mysqli_query($conn, $query);

$outputString = '';

foreach ($result as $row) {
    $userRating = userRating($userId, $row['p_id'], $conn);
    $totalRating = totalRating($row['p_id'], $conn);
    $outputString .= '
        <div class="row-item">
 <div class="row-title">' . $row['p_name'] . '</div> <div class="response" id="response-' . $row['p_id'] . '"></div>
 <ul class="list-inline"  onMouseLeave="mouseOutRating(' . $row['p_id'] . ',' . $userRating . ');"> ';
    
    for ($count = 1; $count <= 5; $count ++) {
        $starRatingId = $row['p_id'] . '_' . $count;
        
        if ($count <= $userRating) {
            
            $outputString .= '<li value="' . $count . '" id="' . $starRatingId . '" class="star selected">&#9733;</li>';
        } else {
            $outputString .= '<li value="' . $count . '"  id="' . $starRatingId . '" class="star" onclick="addRating(' . $row['p_id'] . ',' . $count . ');" onMouseOver="mouseOverRating(' . $row['p_id'] . ',' . $count . ');">&#9733;</li>';
        }
    } // endFor
    
    $outputString .= '
 </ul>
 
 <p class="review-note">Total Reviews: ' . $totalRating . '</p>
 <p class="text-address">' . $row["p_add"] . '</p>
</div>
 ';
}
echo $outputString;
?>