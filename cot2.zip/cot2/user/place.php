<?php
include "header1.php";
//header("refresh: 3;");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<style>
      @import url('https://fonts.googleapis.com/css?family=Open+Sans');
      *,
      :before,
      :after {
        box-sizing: border-box;
      }

      body {
        font-family: 'Open Sans', sans-serif;
        font-size: 13px;
      }

      .button--secondary,
      .button--secondary:visited {
        border-radius: 3px;
        cursor: pointer;
        display: inline-block;
        min-width: 64px;
        font-family: inherit;
        font-size: inherit;
        line-height: 15px;
        outline: none;
        text-align: center;
        text-decoration: none;
        text-shadow: none;
        transition: background 0.1s linear;
        font-weight: 400;
        color: #0090e3;
        background: #fff;
        border: 1px solid #ddd;
        box-shadow: none;
        padding: 15px 15px;
        transition-property: border;
        transition-timing-function: ease-in-out;
        transition-duration: 0.15s;
      }

      .icon-with-text {
        display: inline-flex;
        align-items: flex-start;
      }

      .icon-with-text__icon {
        flex-shrink: 0;
        margin-right: 8px;
        margin-top: -2px;
      }

      .icon-svg--color-silver {
        fill: #cccccc;
        color: #cccccc;
      }

      .icon-svg--color-blue {
        fill: #da2c43;
        color: #da2c43;
      }

      .icon-svg {
        display: inline-block;
        vertical-align: middle;
        height: 16px;
        width: 16px;
      }

      .heart-full {
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
      }

      .btn__effect {
        display: inline-block;
        position: relative;
      }

      .effect-group {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        transform: rotate(25deg);
      }
      .effect-group .effect {
        display: block;
        position: absolute;
        top: 38%;
        left: 50%;
        width: 20px;
        transform-origin: 0px 2px;
      }
      .effect-group .effect:nth-child(2) {
        transform: rotate(72deg);
      }
      .effect-group .effect:nth-child(3) {
        transform: rotate(144deg);
      }
      .effect-group .effect:nth-child(4) {
        transform: rotate(216deg);
      }
      .effect-group .effect:nth-child(5) {
        transform: rotate(288deg);
      }
      .effect-group .effect:before {
        content: '';
        display: block;
        position: absolute;
        right: 0;
        border-radius: 1.5px;
        height: 3px;
        background: #0090e3;
      }
      .effect-group .effect:after {
        content: '';
        display: block;
        position: absolute;
        top: 10px;
        right: 10%;
        border-radius: 50%;
        width: 3px;
        height: 3px;
        background: #ff6600;
        transform: scale(0, 0);
      }

      .active .heart-stroke {
        opacity: 0;
      }
      .active .heart-full {
        opacity: 1;
      }
      .active .icon-svg {
        -webkit-animation: bounceIn 0.5s linear;
        animation: bounceIn 0.5s linear;
      }
      .active .effect:before {
        -webkit-animation: fireworkLine 0.5s linear 0.1s;
        animation: fireworkLine 0.5s linear 0.1s;
      }
      .active .effect:after {
        -webkit-animation: fireworkPoint 0.5s linear 0.1s;
        animation: fireworkPoint 0.5s linear 0.1s;
      }

      .broken-heart {
        position: absolute;
        left: -16px;
        top: 0;
        opacity: 0;
      }
      .broken-heart--left {
        transform: rotate(0deg);
        transform-origin: 60% 200%;
      }
      .broken-heart--right {
        transform: rotate(0deg);
        transform-origin: 63% 200%;
      }
      .broken-heart--crack {
        stroke-dasharray: 15;
        stroke-dashoffset: 15;
      }

      .deactivate .broken-heart {
        opacity: 1;
      }
      .deactivate .broken-heart--left {
        -webkit-animation: crackLeft 0.35s
            cubic-bezier(0.68, -0.55, 0.265, 2.85) 0.15s forwards,
          hide 0.25s ease-in 0.55s forwards;
        animation: crackLeft 0.35s cubic-bezier(0.68, -0.55, 0.265, 2.85) 0.15s
            forwards,
          hide 0.25s ease-in 0.55s forwards;
      }
      .deactivate .broken-heart--right {
        -webkit-animation: crackRight 0.35s
            cubic-bezier(0.68, -0.55, 0.265, 2.85) 0.15s forwards,
          hide 0.25s ease-in 0.55s forwards;
        animation: crackRight 0.35s cubic-bezier(0.68, -0.55, 0.265, 2.85) 0.15s
            forwards,
          hide 0.25s ease-in 0.55s forwards;
      }
      .deactivate .broken-heart--crack {
        -webkit-animation: crack 0.2s ease-in forwards;
        animation: crack 0.2s ease-in forwards;
      }

      @-webkit-keyframes pulse {
        0% {
          opacity: 1;
          transform-origin: center center;
          transform: scale(1);
        }
        50% {
          opacity: 0.6;
          transform: scale(1.15);
        }
        100% {
          opacity: 1;
          transform: scale(1);
        }
      }

      @keyframes pulse {
        0% {
          opacity: 1;
          transform-origin: center center;
          transform: scale(1);
        }
        50% {
          opacity: 0.6;
          transform: scale(1.15);
        }
        100% {
          opacity: 1;
          transform: scale(1);
        }
      }
      @-webkit-keyframes pulseBlue {
        0% {
          transform-origin: center center;
          transform: scale(1);
          fill: #cccccc;
        }
        50% {
          transform: scale(1.15);
          fill: #0090e3;
        }
        100% {
          transform: scale(1);
          fill: #cccccc;
        }
      }
      @keyframes pulseBlue {
        0% {
          transform-origin: center center;
          transform: scale(1);
          fill: #cccccc;
        }
        50% {
          transform: scale(1.15);
          fill: #0090e3;
        }
        100% {
          transform: scale(1);
          fill: #cccccc;
        }
      }
      @-webkit-keyframes fireworkLine {
        0% {
          right: 20%;
          transform: scale(0, 0);
        }
        25% {
          right: 20%;
          width: 6px;
          transform: scale(1, 1);
        }
        35% {
          right: 0;
          width: 35%;
        }
        70% {
          right: 0;
          width: 4px;
          transform: scale(1, 1);
        }
        100% {
          right: 0;
          transform: scale(0, 0);
        }
      }
      @keyframes fireworkLine {
        0% {
          right: 20%;
          transform: scale(0, 0);
        }
        25% {
          right: 20%;
          width: 6px;
          transform: scale(1, 1);
        }
        35% {
          right: 0;
          width: 35%;
        }
        70% {
          right: 0;
          width: 4px;
          transform: scale(1, 1);
        }
        100% {
          right: 0;
          transform: scale(0, 0);
        }
      }
      @-webkit-keyframes fireworkPoint {
        30% {
          transform: scale(0, 0);
        }
        60% {
          transform: scale(1, 1);
        }
        100% {
          transform: scale(0, 0);
        }
      }
      @keyframes fireworkPoint {
        30% {
          transform: scale(0, 0);
        }
        60% {
          transform: scale(1, 1);
        }
        100% {
          transform: scale(0, 0);
        }
      }
      @-webkit-keyframes bounceIn {
        0% {
          transform: scale(0);
        }
        30% {
          transform: scale(1.25);
        }
        50% {
          transform: scale(0.9);
        }
        70% {
          transform: scale(1.1);
        }
        80% {
          transform: scale(1);
        }
      }
      @keyframes bounceIn {
        0% {
          transform: scale(0);
        }
        30% {
          transform: scale(1.25);
        }
        50% {
          transform: scale(0.9);
        }
        70% {
          transform: scale(1.1);
        }
        80% {
          transform: scale(1);
        }
      }
      @-webkit-keyframes crackLeft {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(-45deg);
        }
      }
      @keyframes crackLeft {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(-45deg);
        }
      }
      @-webkit-keyframes crackRight {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(45deg);
        }
      }
      @keyframes crackRight {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(45deg);
        }
      }
      @-webkit-keyframes crack {
        0% {
          stroke-dasharray: 15;
          stroke-dashoffset: 15;
        }
        80% {
          stroke-dasharray: 15;
          stroke-dashoffset: 0;
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @keyframes crack {
        0% {
          stroke-dasharray: 15;
          stroke-dashoffset: 15;
        }
        80% {
          stroke-dasharray: 15;
          stroke-dashoffset: 0;
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @-webkit-keyframes hide {
        0% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @keyframes hide {
        0% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }


      ul {
    margin: 0px;
    padding: 10px 0px 0px 0px;
}

li.star {
    list-style: none;
    display: inline-block;
    margin-right: 5px;
    cursor: pointer;
    color: #9E9E9E;
}

li.star.selected {
    color: #ff6e00;
}

.row-title {
    font-size: 20px;
    color: #00BCD4;
}

.review-note {
    font-size: 12px;
    color: #999;
    font-style: italic;
}
.row-item {
    margin-bottom: 20px;
    border-bottom: #F0F0F0 1px solid;
}
    </style>

</head>
<body>

<?php
	$category = '';
	$searchText = '';
	if(isset($_GET['id']))
    {
        $cat_id=$_GET['id']."";
      //echo "<script>alert('$d_id');</script>";
	  $qry2="SELECT * FROM tbl_category WHERE cat_id='$cat_id'";
      $run2=mysqli_query($con,$qry2);
      $result2=mysqli_fetch_array($run2);
      $category=$result2['category'];
    }
	
	if(isset($_POST['searchText'])){
		$searchText = $_POST['searchText'];
	}
	  
?>
<section class="w3l-grids-3 py-5" >
    <div class="container py-md-5">
  <div class="title-content text-left row mb-lg-5 mb-4">
  <div class="col-md-6">
        <h6 class="sub-title"><?php echo $category; ?></h6>
		</div>

<div class="col-md-6">
		<form action="" method="POST" style="float: right;margin: 10px 0 0 0;" >
	<input type="text" id="searchText" name="searchText" style="width: 250px;" value="<?php echo $searchText; ?>"/>
	<input type="hidden" id="catId" name="catId" value="<?php echo $cat_id; ?>" />
	<input type="submit" value="Search" />
</form>
</div>
      </div>
	
	  
      <div class="row bottom-ab-grids">
  <!--/row-grids-->
  <?php
  
	if(isset($_POST['searchText']) && trim($_POST['searchText']) != ''){
		$cat_id=$_POST['catId']."";
      $qry1="SELECT * FROM tbl_place WHERE cat_id='$cat_id' and p_name like '%".$_POST['searchText']."%'"; 
    } else {
		$qry1="SELECT * FROM tbl_place WHERE p_status='1' AND cat_id='$cat_id'";
	}
  

  $run1=mysqli_query($con,$qry1);
  while($result1=mysqli_fetch_array($run1))
	{
		$p_id=$result1['p_id'];
		$qry3="SELECT * FROM tbl_img WHERE p_id='$p_id'";
		$run3=mysqli_query($con,$qry3);
		$result3=mysqli_fetch_array($run3);
		$image=$result3['img'];
    $qry4="SELECT * FROM `tbl_wishlist` WHERE l_id='$id' AND p_id='$p_id'";
    $run4=mysqli_query($con,$qry4);
    $result4=mysqli_fetch_array($run4);
    $wish = isset($result4['w_status']) ? $result4['w_status'] : 0
  ?>
        <div class="col-lg-6 subject-card mt-lg-0 mt-4" style="margin-bottom: 2%;">
          <div class="subject-card-header p-4">
            <a href="#" class="card_title p-lg-4d-block">
              <div class="row align-items-center">
                <div class="col-sm-5 subject-img"><a href="view_img.php?id=<?php echo $p_id; ?>">
                  <img src="<?php echo $image; ?>" class="img-fluid" alt="">  </a>              
                </div>

                 <div class="col-sm-7 subject-content mt-sm-0 mt-4">

				 <h4><?php echo $result1['p_name']; ?> </h4>
                  <p><?php echo $result1['p_add']; ?></p>
                  <div class="dst-btm">
                    <h6 class="">Opening Days</h6>
                    <span><?php echo $result1['p_open_days']; ?></span>
                  </div>
				  <div class="dst-btm">
                    <h6 class="">Visiting Hours:</h6>
                    <span><?php echo $result1['p_start_time']."-".$result1['p_end_time']; ?></span>
                  </div>
                  <div class="dst-btm">
                    <h6 class="">Website:</h6>
<span><a target="_blank" href="http://<?php echo($result1['p_website']); ?>"><span><?php echo $result1['p_website']; ?></span></a>

                  </div>
                  
          <div class="row">
            <div class="col">
					<?php 
            if($wish == 1)
            {
              echo '<button class="button one active mobile button--secondary wishlist" id= '.$p_id.' >
              <div class="btn__effect">
                <svg
                  class="
                    heart-stroke
                    icon-svg icon-svg--size-4 icon-svg--color-silver
                  "
                  viewBox="20 18 29 28"
                  aria-hidden="true"
                  focusable="false"
                >
                  <path
                    d="M28.3 21.1a4.3 4.3 0 0 1 4.1 2.6 2.5 2.5 0 0 0 2.3 1.7c1 0 1.7-.6 2.2-1.7a3.7 3.7 0 0 1 3.7-2.6c2.7 0 5.2 2.7 5.3 5.8.2 4-5.4 11.2-9.3 15a2.8 2.8 0 0 1-2 1 3.4 3.4 0 0 1-2.2-1c-9.6-10-9.4-13.2-9.3-15 0-1 .6-5.8 5.2-5.8m0-3c-5.3 0-7.9 4.3-8.2 8.5-.2 3.2.4 7.2 10.2 17.4a6.3 6.3 0 0 0 4.3 1.9 5.7 5.7 0 0 0 4.1-1.9c1.1-1 10.6-10.7 10.3-17.3-.2-4.6-4-8.6-8.4-8.6a7.6 7.6 0 0 0-6 2.7 8.1 8.1 0 0 0-6.2-2.7z"
                  ></path>
                </svg>
                <svg
                  class="heart-full icon-svg icon-svg--size-4 icon-svg--color-blue"
                  viewBox="0 0 19.2 18.5"
                  aria-hidden="true"
                  focusable="false"
                >
                  <path
                    d="M9.66 18.48a4.23 4.23 0 0 1-2.89-1.22C.29 10.44-.12 7.79.02 5.67.21 2.87 1.95.03 5.42.01c1.61-.07 3.16.57 4.25 1.76A5.07 5.07 0 0 1 13.6 0c2.88 0 5.43 2.66 5.59 5.74.2 4.37-6.09 10.79-6.8 11.5-.71.77-1.7 1.21-2.74 1.23z"
                  ></path>
                </svg>

                <div class="effect-group">
                  <span class="effect"></span>
                  <span class="effect"></span>
                  <span class="effect"></span>
                  <span class="effect"></span>
                  <span class="effect"></span>
                </div>
              </div>
            </button>';
            }
            else
            {
              echo '<button class="button one deactivate mobile button--secondary wishlist" id= '.$p_id.' >
              <div class="btn__effect">
                <svg
                  class="
                    heart-stroke
                    icon-svg icon-svg--size-4 icon-svg--color-silver
                  "
                  viewBox="20 18 29 28"
                  aria-hidden="true"
                  focusable="false"
                >
                  <path
                    d="M28.3 21.1a4.3 4.3 0 0 1 4.1 2.6 2.5 2.5 0 0 0 2.3 1.7c1 0 1.7-.6 2.2-1.7a3.7 3.7 0 0 1 3.7-2.6c2.7 0 5.2 2.7 5.3 5.8.2 4-5.4 11.2-9.3 15a2.8 2.8 0 0 1-2 1 3.4 3.4 0 0 1-2.2-1c-9.6-10-9.4-13.2-9.3-15 0-1 .6-5.8 5.2-5.8m0-3c-5.3 0-7.9 4.3-8.2 8.5-.2 3.2.4 7.2 10.2 17.4a6.3 6.3 0 0 0 4.3 1.9 5.7 5.7 0 0 0 4.1-1.9c1.1-1 10.6-10.7 10.3-17.3-.2-4.6-4-8.6-8.4-8.6a7.6 7.6 0 0 0-6 2.7 8.1 8.1 0 0 0-6.2-2.7z"
                  ></path>
                </svg>
                <svg
                  class="heart-full icon-svg icon-svg--size-4 icon-svg--color-blue"
                  viewBox="0 0 19.2 18.5"
                  aria-hidden="true"
                  focusable="false"
                >
                  <path
                    d="M9.66 18.48a4.23 4.23 0 0 1-2.89-1.22C.29 10.44-.12 7.79.02 5.67.21 2.87 1.95.03 5.42.01c1.61-.07 3.16.57 4.25 1.76A5.07 5.07 0 0 1 13.6 0c2.88 0 5.43 2.66 5.59 5.74.2 4.37-6.09 10.79-6.8 11.5-.71.77-1.7 1.21-2.74 1.23z"
                  ></path>
                </svg>

                <div class="effect-group">
                  <span class="effect"></span>
                  <span class="effect"></span>
                  <span class="effect"></span>
                  <span class="effect"></span>
                  <span class="effect"></span>
                </div>
              </div>
            </button>';
            }
          ?>
    </div>
    
    <div class="col"> 
      <?php
      echo '<script type="text/javascript">

    function showRestaurantData(url)
    {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200)
            {
                document.getElementById("restaurant_list").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", url, true);
        xhttp.send();

    } 

    function mouseOverRating(restaurantId, rating) {

        resetRatingStars(restaurantId)

        for (var i = 1; i <= rating; i++)
        {
            var ratingId = restaurantId + "_" + i;
            document.getElementById(ratingId).style.color = "#ff6e00";

        }
    }

    function resetRatingStars(restaurantId)
    {
        for (var i = 1; i <= 5; i++)
        {
            var ratingId = restaurantId + "_" + i;
            document.getElementById(ratingId).style.color = "#9E9E9E";
        }
    }

   function mouseOutRating(restaurantId, userRating) {
       var ratingId;
       if(userRating !=0) {
               for (var i = 1; i <= userRating; i++) {
                      ratingId = restaurantId + "_" + i;
                  document.getElementById(ratingId).style.color = "#ff6e00";
               }
       }
       if(userRating <= 5) {
               for (var i = (userRating+1); i <= 5; i++) {
                  ratingId = restaurantId + "_" + i;
              document.getElementById(ratingId).style.color = "#9E9E9E";
           }
       }
    }

    function addRating (restaurantId, ratingValue) {
            var xhttp = new XMLHttpRequest();

            xhttp.onreadystatechange = function ()
            {
                if (this.readyState == 4 && this.status == 200) {

                    showRestaurantData("../rating/getRatingData.php");
                    location.reload();
                    if(this.responseText != "success") {
                           
                    }
                }
            };

            xhttp.open("POST", "../rating/insertRating.php?id='.$id.'", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            var parameters = "index=" + ratingValue + "&p_id=" + restaurantId;
            xhttp.send(parameters);
    }
</script>';
?>
<?php
require_once "../rating/db.php";
require_once "../rating/functions.php";
// Here the user id is harcoded.
// You can integrate your authentication code here to get the logged in user id
$userId = $id;

$query = "SELECT * FROM tbl_place WHERE p_id='$p_id' ORDER BY p_id DESC";
$result = mysqli_query($conn, $query);

$outputString = '';

foreach ($result as $row) {
    $userRating = userRating($userId, $row['p_id'], $conn);
    $totalRating = totalRating($row['p_id'], $conn);
    $outputString .= '
        <div class="row-item">
 
 <ul class="list-inline"  onMouseLeave="mouseOutRating(' . $row['p_id'] . ',' . $userRating . ');"> ';
    
    for ($count = 1; $count <= 5; $count ++) {
        $starRatingId = $row['p_id'] . '_' . $count;
        
        if ($count <= $userRating) {
            
            $outputString .= '<li value="' . $count . '" id="' . $starRatingId . '" class="star selected">&#9733;</li>';
        } else {
            $outputString .= '<li value="' . $count . '"  id="' . $starRatingId . '" class="star" onclick="addRating(' . $row['p_id'] . ',' . $count . ');" onMouseOver="mouseOverRating(' . $row['p_id'] . ',' . $count . ');">&#9733;</li>';
        }
    } // endFor
    
    $outputString .= '
 </ul>
 
 <a class="review-note" href="all_reviews.php?id='.$p_id.'">Total Reviews: ' . $totalRating . '</a>
 
</div>
 ';
}
echo $outputString;
?>
</div>
</div>
 <a href="complain.php?id=<?php echo $p_id; ?>" class="btn btn-success">Complain</a>
 <a target="_blank" href="https://maps.google.com/maps?q=<?php echo str_replace(' ','+',$result1['p_add']); ?>" class="btn btn-blue"><i class="fa fa-arrow-circle-o-right"></i> Direction</a>
                </div>
              </div>
            </a>
          </div>
        </div>
  <?php
	}
  ?>      
          <!--//row-grids-->
      </div>
    </div>
  </section>
  <!--//grids-->
 <script type="text/javascript">
    $(".wishlist").click(function() 
    {
        console.log($(this).attr("id"), <?php echo $id; ?>)
        if ( $(this).hasClass( "deactivate" ) ) 
        {
          $(this).removeClass("deactivate")
          console.log("1")
          $.post("wishlist.php",
          {
            p_Id: $(this).attr("id"),
            l_Id: <?php echo $id; ?>,
            w_Status: 1
          },
          function(data,status)
          {
              console.log(data,status)
          });
          // ADD WISHLIST
        }
        if ( $(this).hasClass( "active" ) ) 
        {
          $(this).addClass("deactivate")
          console.log("0")
          $.post("wishlist.php",
          {
            p_Id: $(this).attr("id"),
            l_Id: <?php echo $id; ?>,
            w_Status: 0
          },
          function(data,status)
          {
              console.log(data,status)
          });
          // REMOVE WISHLIST

        }
        $(this).toggleClass("animate");
        $(this).toggleClass("active");
        
    });
  </script>
<?php
	include "footer.php";
?>