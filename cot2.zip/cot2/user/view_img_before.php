<?php
include "header.php";
//header("refresh: 3;");
  
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" 
  integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


    <link rel="stylesheet" type="text/css" href="demo.css">
    <script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>

</head>
<body>
  

<?php
	
	if(isset($_GET['id']))
       {
        $p_id=$_GET['id']."";
      //echo "<script>alert('$d_id');</script>";
       }
      
?>
<section class="w3l-grids-3 py-5" >
    <div class="container py-md-5">
      <div class="title-content text-left mb-lg-5 mb-4">
        <h6 class="sub-title">Complain</h6>
        <h3 class="hny-title">Places</h3>
      </div>
        
 <?php
    //$qry1="SELECT * FROM tbl_room WHERE r_no='$r_no'";
    //$run1=mysqli_query($con,$qry1);
    //$result1=mysqli_fetch_array($run1);
    
      //s$p_id=$result1['p_id'];
      $qry2="SELECT * FROM tbl_img WHERE p_id='$p_id'";
      $run2=mysqli_query($con,$qry2);
      while($result2=mysqli_fetch_array($run2))
      {
        
    ?>
        <div class="col-lg-4 col-sm-6">
            <div class="thumbnail img-responsive">
                <a href="#" title="Image 1"><img src="<?php echo $result2['img']; ?>"> </a>
            </div>
        </div>
    <?php
     
    }
    ?>
    <div id="modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><i class="fa fa-times"></i></button>
            </div>
            <div class="modal-body">
            </div>
        </div>
    </div>
    </div>


    </div>
  </section>
  <!--//grids-->
  <!-- stats -->
  
<script type="text/javascript" src="gallery.js"></script>
<?php
  include "footer1.php";
?>