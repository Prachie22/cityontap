<?php
  include "header.php";
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
  <style>



/* Add padding to containers */
.container1 {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=file] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}
select
{
width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
select:focus
{
  background-color: #ddd;
  outline: none;
}
textarea
{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
textarea:focus
{
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #e12454;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: #e12454;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
h1
{
  color: #e12454;
}
</style>

</head>
<body>
<div class="container">
  <div class="row">
    <div class="col">
      
    </div>
    <div class="col-8">
        
  <form action="" method="POST">

  <div class="container1" style="margin-top: 12%;">
   <center> <h1>Set Password</h1> </center>
    
    <hr>

    <label><b>Password</b></label>
    <input type="password" placeholder="Enter New Password" name="pass1" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>

    <label><b>Confirm Password</b></label>
    <input type="password" placeholder="Confirm Password" name="pass2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>

   
    

    <button type="submit" class="registerbtn" name="submit">Set</button>
  </div>
  
</form>
   </div>
    <div class="col">
     
    </div>
  </div> 
  </div>        

<?php
	include "footer.php";
  include "connection.php";
  if(isset($_POST['submit']))
  {
    
      $lid=$_GET['id'];
  
  
  $pass1=$_POST['pass1'];
  $pass2=$_POST['pass2'];
  //echo "<script> alert($lid); </script>";
  if($pass1==$pass2)
  {
    //echo "<script> alert('$pass1'); </script>";
      $eqry="UPDATE tbl_login SET l_pass='$pass1' WHERE l_id='$lid'";
          
      $updated=mysqli_query($con,$eqry);
    
    if($updated)
    {
      //echo "<script>  alert('$lid'); </script>";
        echo '<script type="text/javascript">';
       echo 'window.location.href="login.php";';
        echo '</script>';
    
  }
    
  }
  else
  {
    echo "<script>  alert('Both the passwords are different'); </script>";
    header("Refresh: 0; url=set_password.php");
  }


}
?>	
