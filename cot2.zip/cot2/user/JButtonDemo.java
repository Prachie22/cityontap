import java.awt.*;
import javax.swing.*;
/* <applet code=JButtonDemo.class width=150 height=400></applet> */ 
public class JButtonDemo extends JFrame
{
JButtonDemo(String title)
{
super(title);
setLayout(new GridLayout(3,2));
Icon plus= new ImageIcon("plus.png");
JButton b1=new JButton("ADD",plus);
JButton b2=new JButton("OK");
add(b1);
add(b2);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
public static void main(String args[])
{
JButtonDemo t=new JButtonDemo("JButton Demo");
t.setSize(300,100);
t.setVisible(true);
}}