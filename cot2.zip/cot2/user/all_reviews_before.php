<?php
include "header.php";
//header("refresh: 3;");
  
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<style>
     
      ul {
    margin: 0px;
    padding: 10px 0px 0px 0px;
}

li.star {
    list-style: none;
    display: inline-block;
    margin-right: 5px;
    cursor: pointer;
    color: #9E9E9E;
}

li.star.selected {
    color: #ff6e00;
}

.row-title {
    font-size: 20px;
    color: #00BCD4;
}

.review-note {
    font-size: 12px;
    color: #999;
    font-style: italic;
}
.row-item {
    margin-bottom: 20px;
    border-bottom: #F0F0F0 1px solid;
}
    </style>

</head>
<body>

<?php
	
	if(isset($_GET['id']))
       {
        $p_id=$_GET['id']."";
      //echo "<script>alert('$d_id');</script>";
       }
      
?>
<section class="w3l-grids-3 py-5" >
    <div class="container py-md-5">
      <div class="title-content text-left mb-lg-5 mb-4">
        <h6 class="sub-title">Reviews</h6>
        <h3 class="hny-title">Places</h3>
      </div>
      <div class="row bottom-ab-grids">
  <!--/row-grids-->
  <?php
  $qry1="SELECT * FROM tbl_rating WHERE p_id='$p_id'";
  $run1=mysqli_query($con,$qry1);
  while($result1=mysqli_fetch_array($run1))
	{
		//$p_id=$result1['p_id'];
		
		$l_id=$result1['l_id'];

    $qry4="SELECT * FROM tbl_login WHERE l_id='$l_id'";
    $run4=mysqli_query($con,$qry4);
    $result4=mysqli_fetch_array($run4);
    $image=$result4['l_img'];
  ?>
        <div class="col-lg-4 subject-card mt-lg-0 mt-4" style="margin-bottom: 2%;">
          <div class="subject-card-header p-4">
            <a href="#" class="card_title p-lg-4d-block"></a>
              <div class="row align-items-center">
                <div class="col-sm-5 subject-img">
                  <img src="<?php echo $image; ?>" class="img-fluid" alt="">              
                </div>
                 <div class="col-sm-7 subject-content mt-sm-0 mt-4">
				 <h4><?php echo $result4['l_name']; ?> </h4>
                 
           
         
           
      <?php
      echo '<script type="text/javascript">

    function showRestaurantData(url)
    {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200)
            {
                document.getElementById("restaurant_list").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", url, true);
        xhttp.send();

    } 

    function mouseOverRating(restaurantId, rating) {

        resetRatingStars(restaurantId)

        for (var i = 1; i <= rating; i++)
        {
            var ratingId = restaurantId + "_" + i;
            document.getElementById(ratingId).style.color = "#ff6e00";

        }
    }

    function resetRatingStars(restaurantId)
    {
        for (var i = 1; i <= 5; i++)
        {
            var ratingId = restaurantId + "_" + i;
            document.getElementById(ratingId).style.color = "#9E9E9E";
        }
    }

   function mouseOutRating(restaurantId, userRating) {
       var ratingId;
       if(userRating !=0) {
               for (var i = 1; i <= userRating; i++) {
                      ratingId = restaurantId + "_" + i;
                  document.getElementById(ratingId).style.color = "#ff6e00";
               }
       }
       if(userRating <= 5) {
               for (var i = (userRating+1); i <= 5; i++) {
                  ratingId = restaurantId + "_" + i;
              document.getElementById(ratingId).style.color = "#9E9E9E";
           }
       }
    }

    function addRating (restaurantId, ratingValue) {
            var xhttp = new XMLHttpRequest();

            xhttp.onreadystatechange = function ()
            {
                if (this.readyState == 4 && this.status == 200) {

                    showRestaurantData("../rating/getRatingData.php");
                    
                    if(this.responseText != "success") {
                           
                    }
                }
            };

           
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            var parameters = "index=" + ratingValue + "&p_id=" + restaurantId;
            xhttp.send(parameters);
    }
</script>';
?>
<?php
require_once "../rating/db.php";
require_once "../rating/functions.php";
// Here the user id is harcoded.
// You can integrate your authentication code here to get the logged in user id
$userId = $l_id;

$query = "SELECT * FROM tbl_place WHERE p_id='$p_id' ORDER BY p_id DESC";
$result = mysqli_query($conn, $query);

$outputString = '';

foreach ($result as $row) {
    $userRating = userRating($userId, $row['p_id'], $conn);
    $totalRating = totalRating($row['p_id'], $conn);
    $outputString .= '
        <div class="row-item">
 
 <ul class="list-inline"  onMouseLeave="mouseOutRating(' . $row['p_id'] . ',' . $userRating . ');"> ';
    
    for ($count = 1; $count <= 5; $count ++) {
        $starRatingId = $row['p_id'] . '_' . $count;
        
        if ($count <= $userRating) {
            
            $outputString .= '<li value="' . $count . '" id="' . $starRatingId . '" class="star selected">&#9733;</li>';
        } else {
            $outputString .= '<li value="' . $count . '"  id="' . $starRatingId . '" class="star" onclick="addRating(' . $row['p_id'] . ',' . $count . ');" onMouseOver="mouseOverRating(' . $row['p_id'] . ',' . $count . ');">&#9733;</li>';
        }
    } // endFor
    
    $outputString .= '
 </ul>
 
 
</div>
 ';
}
echo $outputString;
?>



                </div>
              </div>
            </a>
          </div>
        </div>
  <?php
	}
  ?>      
          <!--//row-grids-->
      </div>
    </div>
  </section>
  <!--//grids-->
  <!-- stats -->
  <?php echo'<script type="text/javascript">
  	$(".wishlist").click(function() {
  if ( $(this).hasClass( "deactivate" ) ) {
    $(this).removeClass("deactivate")
  }
  if ( $(this).hasClass( "active" ) ) {
    $(this).addClass("deactivate")
  }
  $(this).toggleClass("animate");
  $(this).toggleClass("active");
  $(this).toggleClass("inactive");
});
  </script>';
  ?>
<?php
	include "footer1.php";
?>