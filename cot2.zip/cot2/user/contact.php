<?php
include "header.php";
//header("refresh: 3;");
  
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<style>
    .container1 {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=file], input[type=email] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus, input[type=password]:focus, input[type=email]:focus {
  background-color: #ddd;
  outline: none;
}
select
{
width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
select:focus
{
  background-color: #ddd;
  outline: none;
}
textarea
{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
textarea:focus
{
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: #f8b100;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
h1
{
  color: #e12454;
}
  </style>

</head>
<body>

<section class="w3l-grids-3 py-5" >
    <div class="container py-md-5">
      <div class="title-content text-left mb-lg-5 mb-4">
        
        <center><h3 class="hny-title" style="margin-top: 3%;color:#e12454 ">Get In Touch</h3></center>
      </div>
      <div class="container">
  <div class="row">
    <div class="col">
      
    </div>
    <div class="col-8">
        
  <form action="" method="POST">
  <div class="container1">
    <label for="email"><b>Name</b></label>
    <input type="text" name="name" placeholder="Enter Name" required="">

    <label for="email"><b>Email</b></label>
    <input type="email" name="email" placeholder="Enter Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"  placeholder="Enter Email" required="">

    <label for="email"><b>Phone</b></label>
    <input type="text" name="phone" placeholder="Enter Phone Number" pattern="[6789][0-9]{9}" oninput="setCustomValidity('')" title='Enter 10 Digit mobile
                  number starting with 7 or 8 or 9' required="">

    <label for="email"><b>Message</b></label>
    <textarea placeholder="Enter Message" name="message" required=""></textarea>
    

    <button type="submit" class="registerbtn" style="background-color: rgb(252,20,84);color:white;" name="submit">Submit</button>
  </div>
  
  
</form>
   </div>
    <div class="col">
     
    </div>
  </div> 
  </div>        
    </div>
  </section>
  <!--//grids-->
  <!-- stats -->
  
<?php
	include "footer1.php";
  if(isset($_POST['submit']))
  {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $message=$_POST['message'];
    $qry1="INSERT INTO tbl_contact(c_id,c_name,c_email,c_phone,c_message,c_status)VALUES('','$name','$email','$phone','$message','1')";
    $run1=mysqli_query($con,$qry1);
    if($run1)
    {
      echo "<script>  alert('Thanks for Contacting'); </script>";
      echo "<script> window.location.replace('index.php');</script>";
    }
    else
    {
      echo "<script>  alert('Not Added'); </script>";
            header("Refresh: 0; url=index.php");

    }
  }
?>