<?php
require "header.php";
?>
  
<body>
  <!--banner-slider-->
  <!-- main-slider -->
  <section class="w3l-main-slider" id="home">
    <div class="banner-content">
       <div id="demo-1"
        data-zs-src='["assets/images/Akshardham-Temple-Banner.jpg", "assets/images/slider1.jpg","assets/images/Adalaj-ni-Vav-banner.jpg", "assets/images/Sabarmati Ashram 14.jpg"]'data-zs-overlay="dots">
        <div class="demo-inner-content">
          <div class="container">
            <div class="banner-infhny">
     
              <h6 class="mb-3"></h6>
              <div class="flex-wrap search-wthree-field mt-md-5 mt-4">
                <form action="#" method="post" class="booking-form">
                  <div class="row book-form">
                    <div class="form-input col-md-4 mt-md-0 mt-3">             
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
	  </div>
    </div>
	</div>
  </section>
  <!-- /main-slider -->
  <!-- //banner-slider-->

  
  <!-- stats -->
  <section class="w3l-stats py-5" id="stats" style="margin-left: 8%;">
    <div class="gallery-inner container py-lg-0 py-3">
      <div class="row stats-con pb-lg-3">
        <div class="col-lg-3 col-6 stats_info counter_grid">
          <p class="counter">
            <?php
            $count1 = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(l_id) FROM tbl_login WHERE l_status='1' AND l_role='3'"));
                         echo $count1[0];
            ?>
          </p>
          <h4>Total User</h4>
        </div>
        <div class="col-lg-3 col-6 stats_info counter_grid1">
          <p class="counter"><?php
            $count1 = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(l_id) FROM tbl_login WHERE l_status='1' AND l_role='2'"));
                         echo $count1[0];
            ?></p>
          <h4>Total AMC Employees</h4>
        </div>
        <div class="col-lg-3 col-6 stats_info counter_grid mt-lg-0 mt-5">
          <p class="counter"><?php
            $count1 = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(cat_id) FROM tbl_category WHERE cat_status='1'"));
                         echo $count1[0];
            ?></p>
          <h4>Total Categories</h4>
        </div>
        <div class="col-lg-3 col-6 stats_info counter_grid2 mt-lg-0 mt-5">
          <p class="counter">
            <?php
            $count1 = mysqli_fetch_array(mysqli_query($con, "SELECT COUNT(p_id) FROM tbl_place WHERE p_status='1'"));
                         echo $count1[0];
            ?>
          </p>
          <h4>Total Places</h4>
        </div>

      </div>
    </div>
  </section>
  
  <!--/w3l-bottom-->
  <section class="w3l-bottom py-5">
    <div class="container py-md-4 py-3 text-center">
      <div class="row my-lg-4 mt-4">
        <div class="col-lg-9 col-md-10 ml-auto">
          <div class="bottom-info ml-auto">
            <div class="header-section text-left">
              <h3 class="hny-title two">ABOUT US</h3>
              <p class="mt-3 pr-lg-5">Our aim is to provide users the whole city with just one tap. We provide information about all the places and their reviews which are given by our users. We also help the user to solve their complaints in relation to any place.</p>
             
            </div>
           

          </div>
        </div>
      </div>
    </div>
  </section>
  <!--//w3l-bottom-->
   <div class="best-rooms py-5">
    <div class="container py-md-5">
        <div class="ban-content-inf row">
		 <div class="maghny-gd-1 col-lg-6">
              <div class="maghny-grid">
                <figure class="effect-lily border-radius  m-0">
                    <img class="img-fluid" src="assets/images/Nal11.jpg" alt="" />
                    <figcaption>
                        <div>
                           
                           
                                        
                                    
                        </div>

                    </figcaption>
                </figure>
            </div>
            </div>
           
            <div class="maghny-gd-1 col-lg-6 mt-lg-0 mt-4">
			
			
                <div class="row">
                    <div class="maghny-gd-1 col-6">
                        <div class="maghny-grid">
                            <figure class="effect-lily border-radius">
                                <img class="img-fluid" src="assets/images/H11.jpg" alt="" />
                                <figcaption>
                                    <div>
                                        <h4></h4>
                                    </div>

                                </figcaption>
                            </figure>
                        </div>
                    </div>
                    <div class="maghny-gd-1 col-6">
                        <div class="maghny-grid">
                            <figure class="effect-lily border-radius">
                                <img class="img-fluid" src="assets/images/h3.jpg" alt="" />
                                <figcaption>
                                    <div>
                                        
                                    </div>

                                </figcaption>
                            </figure>
                        </div>
                    </div>
                    <div class="maghny-gd-1 col-6 mt-4">
                        <div class="maghny-grid">
                            <figure class="effect-lily border-radius">
                                <img class="img-fluid" src="assets/images/s8.jpg" alt="" />
                                <figcaption>
                                    <div>
                                        
                                    </div>

                                </figcaption>
                            </figure>
                        </div>
                    </div>
                    <div class="maghny-gd-1 col-6 mt-4">
                        <div class="maghny-grid">
                            <figure class="effect-lily border-radius">
                                <img class="img-fluid" src="assets/images/p1.jpg" alt="" />
                                <figcaption>
                                    <div>
                                        
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

  <!--/w3l-footer-29-main-->
<?PHP 
require "footer1.php";
?>