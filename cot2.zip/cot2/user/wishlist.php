<?php

	include "connection.php";
		
	if(	isset($_POST['p_Id']) AND isset($_POST['l_Id']) AND isset($_POST['w_Status'])	)
	{
		$p_Id = $_POST['p_Id'];
		$l_Id = $_POST['l_Id'];
		$w_Status = $_POST['w_Status'];
   		echo $p_Id."-";
   		echo $l_Id."-";
   		echo $w_Status."-";
	}
	$query = "REPLACE INTO tbl_wishlist (w_status, l_id, p_id) VALUES ('$w_Status', '$l_Id','$p_Id')";
	$exec= mysqli_query($con,$query);
      if($exec)
      {
         echo "data was updated";  
      }
      else
      {
         $msg= "Error: " . $query . "<br>" . mysqli_error($connection);
         echo $msg; 
      }
	
?>