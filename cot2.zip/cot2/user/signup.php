<!DOCTYPE html>
<head>
    <title>Signup Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
        <h1>SIGN-UP</h1>
        <form action="" method="POST">
		<label for="Full Name">Name</label>
        <input type="text" name="name" placeholder="Enter Name" required />
		 
         <label for="email">Email</label>
        <input type="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"  placeholder="Enter Email" required />

        <label for="Full Name">Phone</label>
        <input type="text" name="phone" placeholder="Enter Phone Number" pattern="[6789][0-9]{9}" oninput="setCustomValidity('')" title='Enter 10 Digit mobile
                  number starting with 7 or 8 or 9' required />

        <label for="password">Password</label>
        <input type="password" placeholder="Enter Password" name="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required />

        <label for="password">Address</label>
        <input type="text" name="add" placeholder="Enter Address" required /> 
            

        <label for="image"><b>Profile Pic</b></label>
        <input type="file" name="image">

            <button type="submit" name="submit">Registration</button>
        </form>
        <p>Already User? <a href="login.php">Login here!</a></p>
    </div>
</body>
</html>

<?php
include "connection.php";
    if(isset($_POST['submit']))
        {
            session_start();
        
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $add = $_POST['add'];
        $img = $_POST['image'];
        $image=basename($img);
        //echo $image."<br/>";
        $qry2="SELECT l_email from tbl_login WHERE l_email='$email'";
        
                $result2 = mysqli_query($con,$qry2);
                $c=mysqli_num_rows($result2);
        if($c>=1)
        {
            echo "<script>alert('Same Email Address Exists in Database');</script>";
            header("refresh:0; url=signup.php");
        }

        else
        {   
            if($image)
            {
                $location="photos/".$image;
                //echo $location;
                $query = "INSERT INTO tbl_login(l_id,l_name,l_email,l_phone,l_pass,l_img,l_add,l_role,l_status) VALUES('','$name','$email','$phone','$pass','$location','$add','3','1')";
            
                $result = mysqli_query($con,$query);
                    
                if(!$result)
                {
                    echo "<script>alert('Not Inserted');</script>";
                }
                
                else
                {           
                    header("refresh:0; url=login.php");    
                }
                
            }
            else
            {
                
                $location="photos/Default.png";
                //echo $location;
                 $query = "INSERT INTO tbl_login(l_id,l_name,l_email,l_phone,l_pass,l_img,l_add,l_role,l_status) VALUES('','$name','$email','$phone','$pass','$location','$add','3','1')";
            
            $result = mysqli_query($con,$query);
                if(!$result)
                {
                    echo "<script>alert('Not Inserted');</script>";
                }
                
                else
                {
                    
                    
                    header("refresh:0; url=login.php");
                    
                }
            }
        }
    
}
?>