<?php
	include "header1.php";
?>
<section class="w3l-grids-3 py-5" >
    <div class="container py-md-5">
      <div class="title-content text-left mb-lg-5 mb-4">
        <h6 class="sub-title">Complain</h6>
        <h3 class="hny-title">Manage Complain</h3>
      </div>
      <div class="container">
      	<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Sr No</th>
      <th scope="col">Complain</th>
      <th scope="col">Time</th>
      <th scope="col">Place Name</th>
      <th scope="col">Place Image</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
  $seq=1;
  $qry1="SELECT * FROM tbl_complain WHERE l_id='$id' AND c_status!='0'";
  $run1=mysqli_query($con,$qry1);
  while($result1=mysqli_fetch_array($run1))
  {
  	$p_id=$result1['p_id'];
  	$qry2="SELECT * FROM tbl_place WHERE p_id='$p_id'";
  	$run2=mysqli_query($con,$qry2);
  	$result2=mysqli_fetch_array($run2);

  	$qry3="SELECT * FROM tbl_img WHERE p_id='$p_id'";
  	$run3=mysqli_query($con,$qry3);
  	$result3=mysqli_fetch_array($run3);
  ?>
    <tr>
      <th scope="row"><?php echo $seq; ?></th>
      <td><?php echo $result1['complain']; ?></td>
      <td><?php echo $result1['c_time'];?></td>
      <td><?php echo $result2['p_name'];?></td>
       <td><img src="<?php echo $result3['img'];?>" width="70px" height="70px"></td>
       <?php
       if($result1['c_status']==1)
       {
        echo "<td> Not Solved </td>";
    	}
    	else
    	{
    		 echo "<td>Solved </td>";
    	}
       ?>
       <td><a href="?del=<?php echo $result1['c_id'];?>" onclick="return confirm(' Sure to Delete');" class="btn btn-danger waves-effect waves-light">Delete</a></td>
    </tr>
  <?php
  	$seq++;
	}
	 if(isset($_GET['del']))
										               {
										             // $sql="DELETE FROM tbl_news WHERE news_id=".$_GET['del']."";
										              $sql="UPDATE tbl_complain SET c_status='0' WHERE c_id=".$_GET['del']."";
										              $resultt=mysqli_query($con,$sql);
										            if($resultt)
										                {
										                  echo ("<script>location.href='manage_complain.php'</script>");
										                }
										            
										               }
  ?> 
  </tbody>
</table>
      </div>
  </div>
</section>
<?php
	include "footer.php";
?>