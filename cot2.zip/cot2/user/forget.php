<?php
  include "header.php";
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
  <style>



/* Add padding to containers */
.container1 {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=file] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}
select
{
width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
select:focus
{
	background-color: #ddd;
  outline: none;
}
textarea
{
	width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
textarea:focus
{
	background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #e12454;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: #e12454;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
h1
{
	color: #e12454;
}
</style>

</head>
<body>
<!-- register form start -->
<div class="container" style="margin-top: 8%;">
  <div class="row">
    <div class="col">
      
    </div>
    <div class="col-8">
        
  <form action="check_forget.php" method="POST">
  <div class="container1">
   <center> <h1>Forget Password</h1> </center>
    
    <hr>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>

    

    <button type="submit" class="registerbtn" name="submit">Next</button>
  </div>
  
</form>
   </div>
    <div class="col">
     
    </div>
  </div> 
  </div>        

<?php
	include "footer1.php";
?>	
