<?php 
echo '<button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse"data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"aria-label="Toggle navigation">
          <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
          <span class="navbar-toggler-icon fa icon-close fa-times"></span>
          </span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.html">HOME <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.html">THE CITY</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="services.html">CITIZEN FACILITIES</a>
            </li>
    
            <li class="nav-item">
              <a class="nav-link" href="">AMC</a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="contact.html">HELP LINE</a>
            </li>
			 <li class="nav-item">
              <a class="nav-link" href="about ahemdabad.HTML">ABOUT AHEMDABAD</a>
            </li>

          </ul>
        </div>
        <div class="d-lg-block d-none">
          <a href="login.html" class="btn btn-style btn-secondary">LOGIN</a>
        </div>
        <!-- toggle switch for light and dark theme -->
        <div class="mobile-position">
          <nav class="navigation">
            <div class="theme-switch-wrapper">
              <label class="theme-switch" for="checkbox">
                <input type="checkbox" id="checkbox">
                <div class="mode-container">
                  <i class="gg-sun"></i>
                  <i class="gg-moon"></i>
                </div>
              </label>
            </div>
          </nav>
        </div>';
		
		?>