  <!DOCTYPE html>
  <html>
  <head>
    <title></title>
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  </head>
  <body>
  
  <footer>
    <!-- footer -->
    <section class="w3l-footer">
      <div class="w3l-footer-16-main py-5">
        <div class="container">
         
          
              <div class="row">
                <div class="col-md-6 column">
                  <h3>About Us</h3>
                  <p class="mt-3 pr-lg-5">Our aim is to provide users the whole city with just one tap. We provide information about all the places and their reviews which are given by our users.</p>
                  <p> We also help the user to solve their complaints in relation to any place.</p>
                </div>
                <div class="col-md-3 column mt-md-0 mt-4">
                  <h3>Useful Links</h3>
                  <ul class="footer-gd-16" >
                    <li><a href="dashboard.php">Home</a></li>
            <?php
            $qry1="SELECT * FROM tbl_category WHERE cat_status='1'";
            $run1=mysqli_query($con,$qry1);
            while($result1=mysqli_fetch_array($run1))
            {
              $cat_id=$result1['cat_id'];
            ?>
                    <li><a href="before_place.php?id=<?php echo $cat_id; ?>.php"><?php echo $result1['category']; ?></a></li>
            <?php
            }
            ?>
                    <li><a href="manage_compalin.php">Manage Complain</a></li>
                     
                  </ul>
                </div>
                <div class="col-md-3 column mt-md-0 mt-4">
                  <h3>Get In Touch</h3>
                 <h3><p><i class="fa fa-envelope-o" aria-hidden="true" style="margin-right: 3%"></i>Support Available for 24/7</p></h3>
                 <h3 style="margin-top: -8%;color:rgb(252,20,84);">cityontap@gmail.com</h3>
                 
                 <h3><p><i class="fa fa-phone" aria-hidden="true" style="margin-right: 3%"></i>Contact</p></h3>
                 <h3 style="margin-top: -8%;color:rgb(252,20,84);">+91 9123456789</h3>
                </div>
              </div>
           
           
          
         
        </div>
      </div>
  
      <!-- move top -->
      <button onclick="topFunction()" id="movetop" title="Go to top">
        <span class="fa fa-angle-up"></span>
      </button>
      <script>
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function () {
          scrollFunction()
        };
  
        function scrollFunction() {
          if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("movetop").style.display = "block";
          } else {
            document.getElementById("movetop").style.display = "none";
          }
        }
  
        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
          document.body.scrollTop = 0;
          document.documentElement.scrollTop = 0;
        }
      </script>
      <!-- //move top -->
      <script>
        $(function () {
          $('.navbar-toggler').click(function () {
            $('body').toggleClass('noscroll');
          })
        });
      </script>
    </section>
    <!-- //footer -->
  </footer>
  <!-- Template JavaScript -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/theme-change.js"></script>
  <!--/slider-js-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/modernizr-2.6.2.min.js"></script>
  <script src="assets/js/jquery.zoomslider.min.js"></script>
  <!--//slider-js-->
  <script src="assets/js/owl.carousel.js"></script>
  <!-- script for tesimonials carousel slider -->
  <script>
    $(document).ready(function () {
      $("#owl-demo1").owlCarousel({
        loop: true,
        margin: 20,
        nav: false,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1,
            nav: false
          },
          736: {
            items: 1,
            nav: false
          },
          1000: {
            items: 1,
            nav: false,
            loop: true
          }
        }
      })
    })
  </script>
  <!-- //script for tesimonials carousel slider -->
  <!-- stats number counter-->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <script src="assets/js/jquery.countup.js"></script>
  <script>
    $('.counter').countUp();
  </script>
  <!-- //stats number counter -->

  <!--/MENU-JS-->
  <script>
    $(window).on("scroll", function () {
      var scroll = $(window).scrollTop();

      if (scroll >= 80) {
        $("#site-header").addClass("nav-fixed");
      } else {
        $("#site-header").removeClass("nav-fixed");
      }
    });

    //Main navigation Active Class Add Remove
    $(".navbar-toggler").on("click", function () {
      $("header").toggleClass("active");
    });
    $(document).on("ready", function () {
      if ($(window).width() > 991) {
        $("header").removeClass("active");
      }
      $(window).on("resize", function () {
        if ($(window).width() > 991) {
          $("header").removeClass("active");
        }
      });
    });
  </script>
  <!--//MENU-JS-->

  <script src="assets/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="assets/js/responsive.js "></script>

</body>

</html>