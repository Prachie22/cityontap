<?php
  include "header.php";
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
  <style>



/* Add padding to containers */
.container1 {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=file] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}
select
{
width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
select:focus
{
	background-color: #ddd;
  outline: none;
}
textarea
{
	width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
textarea:focus
{
	background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #e12454;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: #e12454;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
h1
{
	color: #e12454;
}
</style>

</head>
<body>
<!-- register form start -->
<?php
  include "connection.php";
  if(isset($_GET['lid']))
    {
      $lid=$_GET['lid'];
    }
?>
<!-- register form start -->
<div class="container">
  <div class="row">
    <div class="col">
      
    </div>
    <div class="col-8">
        
  <form action="" method="POST">
  <div class="container1">
   <center> <h1>OTP</h1> </center>
    
    <hr>

    <label for="email"><b>OTP</b></label>
    <input type="text" placeholder="Enter OTP" name="otp" required>

   
    

    <button type="submit" class="registerbtn" name="submit"> Next</button>
  </div>
  
</form>
   </div>
    <div class="col">
     
    </div>
  </div> 
  </div>        

<?php
  include "footer1.php";
  if(isset($_POST['submit']))
  {

  $otp_enter=$_POST['otp'];

  $q1="SELECT * FROM tbl_otp ORDER BY o_id DESC LIMIT 1 ";
  $run=mysqli_query($con,$q1);
  $result=mysqli_fetch_array($run);
  $otp=$result['otp'];
  $lid=$result['l_id'];
  //echo "<script>alert('$otp'); </script>";
  if($otp==$otp_enter)
  { 
    echo "<script>location.href='set_password.php?id=$lid'</script>";
    
  }
  else
  {
    echo "<script>alert('Incorrect OTP'); </script>";
     header("location:otp.php?id=".$lid);
    //echo $otp;
  }
}
?>  
