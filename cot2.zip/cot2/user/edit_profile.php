<?php
include "header1.php";
//header("refresh: 3;");
$qry2="SELECT * FROM tbl_login WHERE l_id='$id'";
$run2=mysqli_query($con,$qry2);
$result2=mysqli_fetch_array($run2);
$name=$result2['l_name'];
$email=$result2['l_email'];
$phone=$result2['l_phone'];
$add=$result2['l_add'];
  
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<style>
    .container1 {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=file], input[type=email] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus, input[type=password]:focus, input[type=email]:focus {
  background-color: #ddd;
  outline: none;
}
select
{
width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
select:focus
{
  background-color: #ddd;
  outline: none;
}
textarea
{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
textarea:focus
{
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: #f8b100;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
h1
{
  color: #e12454;
}
  </style>

</head>
<body>

<section class="w3l-grids-3 py-5" >
    <div class="container py-md-5">
      <div class="title-content text-left mb-lg-5 mb-4">
        
        <center><h3 class="hny-title" style="margin-top: 3%;color:#e12454 ">Edit Profile</h3></center>
      </div>
      <div class="container">
  <div class="row">
    <div class="col">
      
    </div>
    <div class="col-8">
        
  <form action="" method="POST">
  <div class="container1">
    <label for="email"><b>Name</b></label>
    <input type="text" name="name" value="<?php echo $name; ?>" required="">

    <label for="email"><b>Email</b></label>
    <input type="email" name="email" value="<?php echo $email; ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"  placeholder="Enter Email" required="">

    <label for="email"><b>Phone</b></label>
    <input type="text" name="phone" value="<?php echo $phone; ?>" pattern="[6789][0-9]{9}" oninput="setCustomValidity('')" title='Enter 10 Digit mobile
                  number starting with 7 or 8 or 9' required="">

    <label for="email"><b>Address</b></label>
    <textarea name="add" required=""><?php echo $add; ?></textarea>

    <label for="email"><b>Upload New DP</b></label>
    <input type="file" name="image" accept="image/*">

    <label for="email"><b>Current DP</b></label>
    <img src="<?php echo $img; ?>" width="120px" height="120px">
	


    <button type="submit" class="registerbtn" style="background-color: rgb(252,20,84);color:white;" name="submit">Submit</button>
  </div>
  
  
</form>
   </div>
    <div class="col">
     
    </div>
  </div> 
  </div>        
    </div>
  </section>
  <!--//grids-->
  <!-- stats -->
  
<?php
	include "footer.php";
 if(isset($_POST['submit']))
    {

        $name=$_POST['name'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
        $add=$_POST['add'];
        $image=$_POST['image'];
        //echo "Hello".$image;
        if($image=="")
        {
            $qry1="UPDATE tbl_login SET l_email='$email', l_name='$name', l_phone='$phone', l_add='$add' WHERE l_id='$id'";
            $run1=mysqli_query($con,$qry1);
            if($run1)
            {
                echo "<script> alert('Profile Updated'); </script>";
                echo "<script> location.replace('dashboard.php'); </script>";    
            }
            else
            {
                echo "<script> alert('Profile Not Updated'); </script>";
                echo "<script> location.replace('edit_profile.php'); </script>";    
            }
        }
        else
        {
            $location="photos/".$image;
            $qry1="UPDATE tbl_login SET l_email='$email', l_name='$name', l_phone='$phone', l_add='$add', l_img='$location' WHERE l_id='$id'";
            $run1=mysqli_query($con,$qry1);
            if($run1)
            {
                echo "<script> alert('Profile Updated'); </script>";
                echo "<script> location.replace('dashboard.php'); </script>";    
            }
            else
            {
                echo "<script> alert('Profile Not Updated'); </script>";
                echo "<script> location.replace('edit_profile.php'); </script>";    
            }   
        }

    }
?>