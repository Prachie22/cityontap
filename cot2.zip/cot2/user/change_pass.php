<?php
include "header1.php";
//header("refresh: 3;");
$qry2="SELECT * FROM tbl_login WHERE l_id='$id'";
$run2=mysqli_query($con,$qry2);
$result2=mysqli_fetch_array($run2);
$name=$result2['l_name'];
$email=$result2['l_email'];
$phone=$result2['l_phone'];
$add=$result2['l_add'];
$l_pass=$result2['l_pass'];
  
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<style>
    .container1 {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=file], input[type=email] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus, input[type=password]:focus, input[type=email]:focus {
  background-color: #ddd;
  outline: none;
}
select
{
width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
select:focus
{
  background-color: #ddd;
  outline: none;
}
textarea
{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
textarea:focus
{
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: #f8b100;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
h1
{
  color: #e12454;
}
  </style>

</head>
<body>

<section class="w3l-grids-3 py-5" >
    <div class="container py-md-5">
      <div class="title-content text-left mb-lg-5 mb-4">
        
        <center><h3 class="hny-title" style="margin-top: 3%;color:#e12454 ">Change Password</h3></center>
      </div>
      <div class="container">
  <div class="row">
    <div class="col">
      
    </div>
    <div class="col-8">
        
  <form action="" method="POST">
  <div class="container1">
    <label for="email"><b>Old Password</b></label>
    <input type="password" placeholder="Enter Old Password" name="pass"required="">

     <label for="email"><b>New Password</b></label>
    <input type="password" placeholder="Enter New Password" name="pass1"required="">

     <label for="email"><b>Confirm Password</b></label>
    <input type="password" placeholder="Confirm New Password" name="pass2"required="">

    <button type="submit" class="registerbtn" style="background-color: rgb(252,20,84);color:white;" name="submit">Submit</button>
  </div>
  
  
</form>
   </div>
    <div class="col">
     
    </div>
  </div> 
  </div>        
    </div>
  </section>
  <!--//grids-->
  <!-- stats -->
  
<?php
	include "footer.php";
if(isset($_POST['submit']))
    {
        $pass=$_POST['pass'];   
        $pass1=$_POST['pass1'];
        $pass2=$_POST['pass2'];
        if($l_pass==$pass)
        {
            if($pass1==$pass2)
            {
                $qry1="UPDATE tbl_login SET l_pass='$pass2' WHERE l_id='$id'";
                $run1=mysqli_query($con,$qry1);
                if($run1)
                {
                    echo "<script> alert('Password Changed'); </script>";
                    echo "<script> location.replace('dashboard.php'); </script>";    
                }
            }
            else
            {
                echo "<script> alert('Both the Passwords are Different'); </script>";
                echo "<script> location.replace('change_pass.php'); </script>";
            }
        }
        else
        {
            echo "<script> alert('Incorrect Old Password'); </script>";
            echo "<script> location.replace('change_pass.php'); </script>";
        }

    }
?>