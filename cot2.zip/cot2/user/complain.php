<?php
include "header1.php";
//header("refresh: 3;");
  
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<style>
    .container1 {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type=file] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}
select
{
width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
select:focus
{
  background-color: #ddd;
  outline: none;
}
textarea
{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
textarea:focus
{
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: #f8b100;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
h1
{
  color: #e12454;
}
  </style>

</head>
<body>

<?php
	
	if(isset($_GET['id']))
       {
        $p_id=$_GET['id']."";
      //echo "<script>alert('$d_id');</script>";
       }
      
?>
<section class="w3l-grids-3 py-5" >
    <div class="container py-md-5">
      <div class="title-content text-left mb-lg-5 mb-4">
        <h6 class="sub-title">Complain</h6>
        <h3 class="hny-title">Places</h3>
      </div>
      <div class="container">
  <div class="row">
    <div class="col">
      
    </div>
    <div class="col-8">
        
  <form action="" method="POST">
  <div class="container1">

    <label for="email"><b>Complain</b></label>
    <textarea placeholder="Enter Complain" name="complain" required=""></textarea>
    <button type="submit" class="registerbtn" style="background-color: rgb(252,20,84);color:white;" name="submit">Submit</button>
  </div>
  
  
</form>
   </div>
    <div class="col">
     
    </div>
  </div> 
  </div>        
    </div>
  </section>
  <!--//grids-->
  <!-- stats -->
  
<?php
	include "footer.php";
	
  if(isset($_POST['submit']))
  {
	 $complain=$_POST['complain'];
    $qry1="INSERT INTO tbl_complain(c_id,complain,c_time,c_status,l_id,p_id)VALUES('','$complain',NOW(),'1','$id','$p_id')";
    $run1=mysqli_query($con,$qry1);
    if($run1)
    {
      echo "<script>  alert('Complain Added'); </script>";
      echo "<script> window.location.replace('manage_complain.php');</script>";
    }
    else
    {
      echo "<script>  alert('Complain Not Added'); </script>";
            header("Refresh: 0; url=complain.php");

    }
  }
?>