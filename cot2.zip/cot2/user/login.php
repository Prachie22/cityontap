<!DOCTYPE html>
<head>

  

    <title>Login Form </title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
        <h1>LOGIN</h1>
        <form action="check_login.php" method="POST">
            <label for="email">Email</label>
        <input type="email" name="email" id="email" required />
        <label for="password">Password</label>
        <input type="password" name="pass" id="password" required />
            <button type="submit" name="submit">Log-in</button>
        </form>
		
        <p>New User? <a href="signup.php">Signup here!</a>
        <p>Forget Password? <a href="forget.php">Click here!</a>
        </p>
    </div>	

