<?php
include "header.php";
//header("refresh: 3;");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<style>
      @import url('https://fonts.googleapis.com/css?family=Open+Sans');
      *,
      :before,
      :after {
        box-sizing: border-box;
      }

      body {
        font-family: 'Open Sans', sans-serif;
        font-size: 13px;
      }

      .button--secondary,
      .button--secondary:visited {
        border-radius: 3px;
        cursor: pointer;
        display: inline-block;
        min-width: 64px;
        font-family: inherit;
        font-size: inherit;
        line-height: 15px;
        outline: none;
        text-align: center;
        text-decoration: none;
        text-shadow: none;
        transition: background 0.1s linear;
        font-weight: 400;
        color: #0090e3;
        background: #fff;
        border: 1px solid #ddd;
        box-shadow: none;
        padding: 15px 15px;
        transition-property: border;
        transition-timing-function: ease-in-out;
        transition-duration: 0.15s;
      }

      .icon-with-text {
        display: inline-flex;
        align-items: flex-start;
      }

      .icon-with-text__icon {
        flex-shrink: 0;
        margin-right: 8px;
        margin-top: -2px;
      }

      .icon-svg--color-silver {
        fill: #cccccc;
        color: #cccccc;
      }

      .icon-svg--color-blue {
        fill: #da2c43;
        color: #da2c43;
      }

      .icon-svg {
        display: inline-block;
        vertical-align: middle;
        height: 16px;
        width: 16px;
      }

      .heart-full {
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
      }

      .btn__effect {
        display: inline-block;
        position: relative;
      }

      .effect-group {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        transform: rotate(25deg);
      }
      .effect-group .effect {
        display: block;
        position: absolute;
        top: 38%;
        left: 50%;
        width: 20px;
        transform-origin: 0px 2px;
      }
      .effect-group .effect:nth-child(2) {
        transform: rotate(72deg);
      }
      .effect-group .effect:nth-child(3) {
        transform: rotate(144deg);
      }
      .effect-group .effect:nth-child(4) {
        transform: rotate(216deg);
      }
      .effect-group .effect:nth-child(5) {
        transform: rotate(288deg);
      }
      .effect-group .effect:before {
        content: '';
        display: block;
        position: absolute;
        right: 0;
        border-radius: 1.5px;
        height: 3px;
        background: #0090e3;
      }
      .effect-group .effect:after {
        content: '';
        display: block;
        position: absolute;
        top: 10px;
        right: 10%;
        border-radius: 50%;
        width: 3px;
        height: 3px;
        background: #ff6600;
        transform: scale(0, 0);
      }

      .active .heart-stroke {
        opacity: 0;
      }
      .active .heart-full {
        opacity: 1;
      }
      .active .icon-svg {
        -webkit-animation: bounceIn 0.5s linear;
        animation: bounceIn 0.5s linear;
      }
      .active .effect:before {
        -webkit-animation: fireworkLine 0.5s linear 0.1s;
        animation: fireworkLine 0.5s linear 0.1s;
      }
      .active .effect:after {
        -webkit-animation: fireworkPoint 0.5s linear 0.1s;
        animation: fireworkPoint 0.5s linear 0.1s;
      }

      .broken-heart {
        position: absolute;
        left: -16px;
        top: 0;
        opacity: 0;
      }
      .broken-heart--left {
        transform: rotate(0deg);
        transform-origin: 60% 200%;
      }
      .broken-heart--right {
        transform: rotate(0deg);
        transform-origin: 63% 200%;
      }
      .broken-heart--crack {
        stroke-dasharray: 15;
        stroke-dashoffset: 15;
      }

      .deactivate .broken-heart {
        opacity: 1;
      }
      .deactivate .broken-heart--left {
        -webkit-animation: crackLeft 0.35s
            cubic-bezier(0.68, -0.55, 0.265, 2.85) 0.15s forwards,
          hide 0.25s ease-in 0.55s forwards;
        animation: crackLeft 0.35s cubic-bezier(0.68, -0.55, 0.265, 2.85) 0.15s
            forwards,
          hide 0.25s ease-in 0.55s forwards;
      }
      .deactivate .broken-heart--right {
        -webkit-animation: crackRight 0.35s
            cubic-bezier(0.68, -0.55, 0.265, 2.85) 0.15s forwards,
          hide 0.25s ease-in 0.55s forwards;
        animation: crackRight 0.35s cubic-bezier(0.68, -0.55, 0.265, 2.85) 0.15s
            forwards,
          hide 0.25s ease-in 0.55s forwards;
      }
      .deactivate .broken-heart--crack {
        -webkit-animation: crack 0.2s ease-in forwards;
        animation: crack 0.2s ease-in forwards;
      }

      @-webkit-keyframes pulse {
        0% {
          opacity: 1;
          transform-origin: center center;
          transform: scale(1);
        }
        50% {
          opacity: 0.6;
          transform: scale(1.15);
        }
        100% {
          opacity: 1;
          transform: scale(1);
        }
      }

      @keyframes pulse {
        0% {
          opacity: 1;
          transform-origin: center center;
          transform: scale(1);
        }
        50% {
          opacity: 0.6;
          transform: scale(1.15);
        }
        100% {
          opacity: 1;
          transform: scale(1);
        }
      }
      @-webkit-keyframes pulseBlue {
        0% {
          transform-origin: center center;
          transform: scale(1);
          fill: #cccccc;
        }
        50% {
          transform: scale(1.15);
          fill: #0090e3;
        }
        100% {
          transform: scale(1);
          fill: #cccccc;
        }
      }
      @keyframes pulseBlue {
        0% {
          transform-origin: center center;
          transform: scale(1);
          fill: #cccccc;
        }
        50% {
          transform: scale(1.15);
          fill: #0090e3;
        }
        100% {
          transform: scale(1);
          fill: #cccccc;
        }
      }
      @-webkit-keyframes fireworkLine {
        0% {
          right: 20%;
          transform: scale(0, 0);
        }
        25% {
          right: 20%;
          width: 6px;
          transform: scale(1, 1);
        }
        35% {
          right: 0;
          width: 35%;
        }
        70% {
          right: 0;
          width: 4px;
          transform: scale(1, 1);
        }
        100% {
          right: 0;
          transform: scale(0, 0);
        }
      }
      @keyframes fireworkLine {
        0% {
          right: 20%;
          transform: scale(0, 0);
        }
        25% {
          right: 20%;
          width: 6px;
          transform: scale(1, 1);
        }
        35% {
          right: 0;
          width: 35%;
        }
        70% {
          right: 0;
          width: 4px;
          transform: scale(1, 1);
        }
        100% {
          right: 0;
          transform: scale(0, 0);
        }
      }
      @-webkit-keyframes fireworkPoint {
        30% {
          transform: scale(0, 0);
        }
        60% {
          transform: scale(1, 1);
        }
        100% {
          transform: scale(0, 0);
        }
      }
      @keyframes fireworkPoint {
        30% {
          transform: scale(0, 0);
        }
        60% {
          transform: scale(1, 1);
        }
        100% {
          transform: scale(0, 0);
        }
      }
      @-webkit-keyframes bounceIn {
        0% {
          transform: scale(0);
        }
        30% {
          transform: scale(1.25);
        }
        50% {
          transform: scale(0.9);
        }
        70% {
          transform: scale(1.1);
        }
        80% {
          transform: scale(1);
        }
      }
      @keyframes bounceIn {
        0% {
          transform: scale(0);
        }
        30% {
          transform: scale(1.25);
        }
        50% {
          transform: scale(0.9);
        }
        70% {
          transform: scale(1.1);
        }
        80% {
          transform: scale(1);
        }
      }
      @-webkit-keyframes crackLeft {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(-45deg);
        }
      }
      @keyframes crackLeft {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(-45deg);
        }
      }
      @-webkit-keyframes crackRight {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(45deg);
        }
      }
      @keyframes crackRight {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(45deg);
        }
      }
      @-webkit-keyframes crack {
        0% {
          stroke-dasharray: 15;
          stroke-dashoffset: 15;
        }
        80% {
          stroke-dasharray: 15;
          stroke-dashoffset: 0;
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @keyframes crack {
        0% {
          stroke-dasharray: 15;
          stroke-dashoffset: 15;
        }
        80% {
          stroke-dasharray: 15;
          stroke-dashoffset: 0;
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @-webkit-keyframes hide {
        0% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }
      @keyframes hide {
        0% {
          opacity: 1;
        }
        100% {
          opacity: 0;
        }
      }


      ul {
    margin: 0px;
    padding: 10px 0px 0px 0px;
}

li.star {
    list-style: none;
    display: inline-block;
    margin-right: 5px;
    cursor: pointer;
    color: #9E9E9E;
}

li.star.selected {
    color: #ff6e00;
}

.row-title {
    font-size: 20px;
    color: #00BCD4;
}

.review-note {
    font-size: 12px;
    color: #999;
    font-style: italic;
}
.row-item {
    margin-bottom: 20px;
    border-bottom: #F0F0F0 1px solid;
}
    </style>

</head>
<body>


<?php
	$category = '';
	$searchText = '';
	if(isset($_GET['id']))
    {
        $cat_id=$_GET['id']."";
      //echo "<script>alert('$d_id');</script>";
	  $qry2="SELECT * FROM tbl_category WHERE cat_id='$cat_id'";
      $run2=mysqli_query($con,$qry2);
      $result2=mysqli_fetch_array($run2);
      $category=$result2['category'];
    }
	
	if(isset($_POST['searchText'])){
		$searchText = $_POST['searchText'];
	}
	  
?>
<section class="w3l-grids-3 py-5" >
    <div class="container py-md-5">
  <div class="title-content text-left row mb-lg-5 mb-4">
  <div class="col-md-6">
        <h6 class="sub-title"><?php echo $category; ?></h6>
		</div>

<div class="col-md-6">
		<form action="" method="POST" style="float: right;margin: 10px 0 0 0;" >
	<input type="text" id="searchText" name="searchText" style="width: 250px;" value="<?php echo $searchText; ?>"/>
	<input type="hidden" id="catId" name="catId" value="<?php echo $cat_id; ?>" />
	<input type="submit" value="Search" />
</form>
</div>
      </div>
	
	  
      <div class="row bottom-ab-grids">
  <!--/row-grids-->
  <?php
  
	if(isset($_POST['searchText']) && trim($_POST['searchText']) != ''){
		$cat_id=$_POST['catId']."";
      $qry1="SELECT * FROM tbl_place WHERE cat_id='$cat_id' and p_name like '%".$_POST['searchText']."%'"; 
    } else {
		$qry1="SELECT * FROM tbl_place WHERE p_status='1' AND cat_id='$cat_id'";
	}
  
  $run1=mysqli_query($con,$qry1);
  while($result1=mysqli_fetch_array($run1))
	{
		$p_id=$result1['p_id'];
		$qry3="SELECT * FROM tbl_img WHERE p_id='$p_id'";
		$run3=mysqli_query($con,$qry3);
		$result3=mysqli_fetch_array($run3);
		$image=$result3['img'];
  ?>
        <div class="col-lg-6 subject-card mt-lg-0 mt-4" style="margin-bottom: 2%;">
          <div class="subject-card-header p-4">
            <a href="#" class="card_title p-lg-4d-block">
              <div class="row align-items-center">
                <div class="col-sm-5 subject-img"><a href="view_img_before.php?id=<?php echo $p_id; ?>">
                  <img src="<?php echo $image; ?>" class="img-fluid" alt="">  </a>              
                </div>

                 <div class="col-sm-7 subject-content mt-sm-0 mt-4">

				 <h4><?php echo $result1['p_name']; ?> </h4>
                  <p><?php echo $result1['p_add']; ?></p>
                  <div class="dst-btm">
                    <h6 class="">Opening Days</h6>
                    <span><?php echo $result1['p_open_days']; ?></span>
                  </div>
				  <div class="dst-btm">
                    <h6 class="">Visiting Hours:</h6>
                    <span><?php echo $result1['p_start_time']."-".$result1['p_end_time']; ?></span>
                  </div>
                  <div class="dst-btm">
                    <h6 class="">Website:</h6>
                    <span><a target="_blank" href="http://<?php echo($result1['p_website']); ?>"><span><?php echo $result1['p_website']; ?></span></a>
					
                  </div>
             
                  
          
<div class="dst-btm">
                    <h6 class="">Reviews:</h6>
                    
      <?php
      echo '<script type="text/javascript">

    function showRestaurantData(url)
    {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200)
            {
                document.getElementById("restaurant_list").innerHTML = this.responseText;
            }
        };
        xhttp.open("GET", url, true);
        xhttp.send();

    } 

    function mouseOverRating(restaurantId, rating) {

        resetRatingStars(restaurantId)

        for (var i = 1; i <= rating; i++)
        {
            var ratingId = restaurantId + "_" + i;
            document.getElementById(ratingId).style.color = "#ff6e00";

        }
    }

    function resetRatingStars(restaurantId)
    {
        for (var i = 1; i <= 5; i++)
        {
            var ratingId = restaurantId + "_" + i;
            document.getElementById(ratingId).style.color = "#9E9E9E";
        }
    }

   function mouseOutRating(restaurantId, userRating) {
       var ratingId;
       if(userRating !=0) {
               for (var i = 1; i <= userRating; i++) {
                      ratingId = restaurantId + "_" + i;
                  document.getElementById(ratingId).style.color = "#ff6e00";
               }
       }
       if(userRating <= 5) {
               for (var i = (userRating+1); i <= 5; i++) {
                  ratingId = restaurantId + "_" + i;
              document.getElementById(ratingId).style.color = "#9E9E9E";
           }
       }
    }

    function addRating (restaurantId, ratingValue) {
            var xhttp = new XMLHttpRequest();

            xhttp.onreadystatechange = function ()
            {
                if (this.readyState == 4 && this.status == 200) {

                    showRestaurantData("../rating/getRatingData.php");
                    
                    if(this.responseText != "success") {
                           
                    }
                }
            };

            xhttp.open("POST", "../rating/insertRating.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            var parameters = "index=" + ratingValue + "&p_id=" + restaurantId;
            xhttp.send(parameters);
    }
</script>';
?>
<?php
require_once "../rating/db.php";
require_once "../rating/function1.php";
// Here the user id is harcoded.
// You can integrate your authentication code here to get the logged in user id
//$userId = $id;

$query = "SELECT * FROM tbl_place WHERE p_id='$p_id' ORDER BY p_id DESC";
$result = mysqli_query($conn, $query);

$outputString = '';

foreach ($result as $row) {
    $userRating = userRating($row['p_id'], $conn);
    $totalRating = totalRating($row['p_id'], $conn);
    $outputString .= '
        <div class="row-item">
 
 <ul class="list-inline"  onMouseLeave="mouseOutRating(' . $row['p_id'] . ',' . $userRating . ');"> ';
    
    
    
    $outputString .= '
 </ul>
 
 <span><a style="color:rgb(252,20,84);" href="all_reviews_before.php?id='.$p_id.'">Total Reviews: ' . $totalRating . '</a></span>
 
</div>
 ';
}
echo $outputString;
?>

                  </div>
<a target="_blank" href="https://maps.google.com/maps?q=<?php echo str_replace(' ','+',$result1['p_add']); ?>" class="btn btn-blue"><i class="fa fa-arrow-circle-o-right"></i> Direction</a>
 
                </div>
              </div>
            </a>
          </div>
        </div>
  <?php
	}
  ?>      
          <!--//row-grids-->
      </div>
    </div>
  </section>
  <!--//grids-->
  <!-- stats -->
  <?php echo'<script type="text/javascript">
  	$(".wishlist").click(function() {
  if ( $(this).hasClass( "deactivate" ) ) {
    $(this).removeClass("deactivate")
  }
  if ( $(this).hasClass( "active" ) ) {
    $(this).addClass("deactivate")
  }
  $(this).toggleClass("animate");
  $(this).toggleClass("active");
  $(this).toggleClass("inactive");
});
  </script>';
  ?>
<?php
	include "footer1.php";
?>