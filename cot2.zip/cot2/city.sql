-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2022 at 07:21 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `city`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cat_id` int(11) NOT NULL,
  `category` varchar(30) DEFAULT NULL,
  `cat_status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cat_id`, `category`, `cat_status`) VALUES
(1, 'Heritage', '1'),
(2, 'Hotels', '1'),
(3, 'Health', '1'),
(4, 'Education', '1'),
(5, 'Entertainment', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complain`
--

CREATE TABLE `tbl_complain` (
  `c_id` int(11) NOT NULL,
  `complain` varchar(100) DEFAULT NULL,
  `c_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `c_status` varchar(5) DEFAULT NULL,
  `l_id` int(11) DEFAULT NULL,
  `p_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_complain`
--

INSERT INTO `tbl_complain` (`c_id`, `complain`, `c_time`, `c_status`, `l_id`, `p_id`) VALUES
(1, 'Not Satisfied with the Service', '2022-02-09 07:53:40', '2', 9, 2),
(2, 'not happy with the service', '2022-03-21 16:53:47', '2', 9, 3),
(3, 'Not Happy', '2022-02-09 07:46:08', '2', 11, 5),
(4, 'not satisfied', '2022-02-09 11:54:29', '2', 11, 3),
(5, 'Really bad service ', '2022-04-03 04:42:29', '2', 7, 9),
(6, 'Really bad Service there ', '2022-03-21 17:03:46', '0', 17, 9),
(7, 'Not Satisfied with the Service', '2022-03-24 04:20:34', '1', 1, 14),
(8, 'fgdgh', '2022-03-24 07:22:17', '1', 7, 1),
(10, 'bed ', '2022-03-31 03:55:48', '1', 19, 9),
(11, 'hhhhhhhhhh', '2022-04-05 06:01:54', '1', 17, 1),
(12, 'dddddd', '2022-04-05 06:03:17', '1', 17, 9),
(13, 'ssssssssss', '2022-04-05 06:08:46', '1', 17, 1),
(14, 'h', '2022-04-05 06:08:32', '1', 17, 1),
(15, 'f', '2022-04-05 06:10:03', '1', 17, 1),
(16, 'ssssss', '2022-04-05 06:13:17', '1', 17, 1),
(17, 'Not Satisfied with the Service', '2022-04-11 12:22:06', '1', 17, 15);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complain_status`
--

CREATE TABLE `tbl_complain_status` (
  `cs_id` int(11) NOT NULL,
  `l_id` int(11) DEFAULT NULL,
  `c_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_complain_status`
--

INSERT INTO `tbl_complain_status` (`cs_id`, `l_id`, `c_id`) VALUES
(2, 8, 3),
(3, 7, 1),
(4, 7, 4),
(5, 7, 6),
(6, 17, 2),
(7, 7, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(50) DEFAULT NULL,
  `c_email` varchar(50) DEFAULT NULL,
  `c_phone` varchar(20) DEFAULT NULL,
  `c_message` varchar(200) DEFAULT NULL,
  `c_status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`c_id`, `c_name`, `c_email`, `c_phone`, `c_message`, `c_status`) VALUES
(1, 'user7', 'user7@gmail.com', '9823456791', 'Enquiry to join', '1'),
(2, 'user1', 'user1@gmail.com', '9898989898', 'Request to solve my complain', '1'),
(3, 'Hetvi', 'hetvi13patel@gmail.com', '8976654434', 'Hello, can i visit Ahmedabad Darshan from your site ', '1'),
(4, 'user', 'user1@gmail.com', '8976654434', 'hello', '1'),
(5, 'User19', 'user9@gmali.com', '9879055143', 'hii ', '1'),
(6, 'hetvi patel', 'hetvi13patel@gmali.com', '9866722334', 'hiiii', '1'),
(7, 'user', 'user1@gmail.com', '9377719783', 'hii i am visit ahmedabad\r\n', '1'),
(8, 'user', 'user1@gmail.com', '9879055143', 'hello\r\n', '1'),
(9, 'user', 'user1@gmail.com', '9866722334', 'hello', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_img`
--

CREATE TABLE `tbl_img` (
  `i_id` int(11) NOT NULL,
  `img` varchar(50) DEFAULT NULL,
  `p_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_img`
--

INSERT INTO `tbl_img` (`i_id`, `img`, `p_id`) VALUES
(1, 'photos/JU1.jpg', 1),
(2, 'photos/h3.jpg', 2),
(3, 'photos/ad1.jpg', 3),
(5, 'photos/s1.jpg', 4),
(7, 'photos/Sabarmati.jpg', 5),
(8, 'photos/Nalsarovar-Bird-Sanctuary-1.jpg', 6),
(9, 'photos/Auto-World.jpg', 7),
(10, 'photos/science-city2.jpg', 8),
(11, 'photos/taj.jpg', 9),
(12, 'photos/novtel.jpg', 10),
(13, 'photos/hyatt.jpg', 11),
(14, 'photos/radisson.jpg', 12),
(15, 'photos/exterior.jpg', 13),
(16, 'photos/cims.jpg', 16),
(17, 'photos/zydus_5.jpg', 17),
(18, 'photos/kd.webp', 18),
(19, 'photos/hcg.jpg', 19),
(20, 'photos/sterling.jpg', 20),
(22, 'photos/gujarat.jpg', 21),
(23, 'photos/nirma.jpg', 22),
(24, 'photos/l_d_eng.jpg', 23),
(26, 'photos/dps1.jpeg', 25),
(27, 'photos/anand niketan.jpg', 26),
(28, 'photos/alpha.jpg', 28),
(29, 'photos/pvr.jpg', 29),
(30, 'photos/the1.jpg', 30),
(31, 'photos/100acres.jpg', 31),
(32, 'photos/rajpath1.jpg', 32),
(33, 'photos/tank-like-patang-hotel.jpg', 14),
(34, 'photos/Civil-Hospital-in-Ahmedabad.jpg', 15),
(35, 'photos/Agora-mall.webp', 27),
(36, 'photos/gpg.jpg', 24);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `l_id` int(11) NOT NULL,
  `l_name` varchar(50) DEFAULT NULL,
  `l_email` varchar(50) DEFAULT NULL,
  `l_phone` varchar(20) DEFAULT NULL,
  `l_pass` varchar(20) DEFAULT NULL,
  `l_add` varchar(100) DEFAULT NULL,
  `l_img` varchar(20) DEFAULT NULL,
  `l_status` varchar(10) DEFAULT NULL,
  `l_role` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`l_id`, `l_name`, `l_email`, `l_phone`, `l_pass`, `l_add`, `l_img`, `l_status`, `l_role`) VALUES
(1, 'admin123', 'admin1@gmail.com', '9999999988', 'Admin123', 'Ahmedabad', 'photos/user3.jpg', '1', '1'),
(2, 'admin2', 'admin2@gmail.com', '9898989898', 'Admin123', 'abad', 'photos/user7.png', '1', '1'),
(6, 'admin3', 'admin3@gmail.com', '9898989898', 'HCMUWV', 'abad', 'photos/Default.png', '1', '1'),
(7, 'employee12', 'employee1@gmail.com', '9898989898', 'Employee123', 'abad', 'photos/user8.png', '1', '2'),
(8, 'employee2', 'employee2@gmail.com', '9898989898', 'NGUSQA', 'abad', 'photos/Default.png', '1', '2'),
(9, 'user1', 'user1@gmail.com', '9999999998', 'User12345', 'abad', 'photos/user9.png', '1', '3'),
(10, 'user2', 'user2@gmail.com', '9999999999', 'User1234', 'abad', 'photos/user2.jpg', '1', '3'),
(11, 'user3', 'user3@gmail.com', '9999999999', 'User1234', 'abad', 'photos/user5.png', '1', '3'),
(12, 'user4', 'user4@gmail.com', '9999999999', 'User1234', 'abad', 'photos/user8.png', '1', '3'),
(13, 'user5', 'user5@gmail.com', '9999999999', 'User1234', 'abad', 'photos/user4.jpg', '1', '3'),
(14, 'user6', 'user6@gmail.com', '9898989898', 'User1234', 'abad', 'photos/user6.png', '1', '3'),
(16, 'admin4', 'admin4@gmail.com', '9898989898', 'FOPWS9', 'abad', 'photos/Default.png', '0', '1'),
(17, 'hetvi patel', 'hetvi13patel@gmali.com', '9999999999', 'Hetvi12345', 'ssssssss', 'photos/Default.png', '1', '3'),
(18, 'admin4', 'admin4@gmali.com', '9879055143', 'DO54CY', 'gujarat', 'photos/Default.png', '0', '1'),
(19, 'User19', 'user9@gmali.com', '9377719783', 'User123456789', 'ahmedabad', 'photos/user8.png', '1', '3'),
(20, 'emp1', 'emp2@gmail.com', '9866722334', 'WTIGRM', 'ahmedabad\r\n', 'photos/Default.png', '1', '2'),
(21, 'User1012', 'user10@gmali.com', '9879055143', 'User@1213', 'ahmedabad', 'photos/user8.png', '1', '3'),
(23, 'user1345', 'user13@gmali.com', '9879055143', 'User@1316', 'ahmedabad', 'photos/Default.png', '1', '3'),
(24, 'admin7', 'admin7@gmali.com', '8976654434', '84AG3C', 'Ahmedabad', 'photos/Default.png', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_otp`
--

CREATE TABLE `tbl_otp` (
  `o_id` int(11) NOT NULL,
  `otp` varchar(10) DEFAULT NULL,
  `o_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `l_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_otp`
--

INSERT INTO `tbl_otp` (`o_id`, `otp`, `o_time`, `l_id`) VALUES
(29, '338115', '2022-02-09 11:34:45', 9),
(30, '862559', '2022-03-19 12:22:17', 1),
(31, '907572', '2022-03-19 12:22:26', 17),
(32, '142008', '2022-03-23 06:00:02', 17),
(33, '224687', '2022-03-23 06:00:14', 17),
(34, '748192', '2022-03-27 06:38:12', 17),
(35, '723630', '2022-03-27 06:41:09', 9),
(36, '672511', '2022-03-27 06:51:13', 9),
(37, '373073', '2022-03-27 06:52:07', 17),
(38, '247289', '2022-03-30 16:23:00', 7),
(39, '868312', '2022-04-05 16:32:46', 17),
(40, '452487', '2022-04-29 05:16:24', 7),
(41, '842195', '2022-04-29 05:16:33', 7);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_place`
--

CREATE TABLE `tbl_place` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(50) DEFAULT NULL,
  `p_start_time` varchar(20) DEFAULT NULL,
  `p_end_time` varchar(20) DEFAULT NULL,
  `p_open_days` varchar(50) NOT NULL,
  `p_website` varchar(500) DEFAULT NULL,
  `p_add` varchar(250) DEFAULT NULL,
  `p_status` int(5) NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `l_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_place`
--

INSERT INTO `tbl_place` (`p_id`, `p_name`, `p_start_time`, `p_end_time`, `p_open_days`, `p_website`, `p_add`, `p_status`, `cat_id`, `l_id`) VALUES
(1, 'Jhulta Minara ', '05:30', '09:00', 'mon-sun', '-', 'opp. Sarangpur Water Tank, Sakar Bazzar, Kalupur, Ahmedabad, Gujarat 380002', 1, 1, 17),
(2, 'Jama Masjid', '06:00', '08:00', 'mon-sun', 'asmwc.org', 'jama masjid Manek Chowk, Gandhi Rd, Danapidth, Khadia, Ahmedabad, Gujarat 380001', 1, 1, 17),
(3, 'The Adalaj Stepwell', '06:00', '06:00', 'mon-sun', '-', 'Adalaj Stepwell Adalaj Rd, Adalaj, Gujarat 382421', 1, 1, 17),
(4, 'Sidi Saiyyed Mosque', '07:00', '06:00', 'mon-sun', '-', 'Sidi Saiyyed Gheekanta,LalDarwaja,Ahmedabad', 1, 1, 17),
(5, 'Sabarmati Ashram', '08:30', '06:30', 'mon-sun', 'gandhiashramsabarmati.org', ' Sabarmati Ashram Gandhi Smarak Sangrahalaya, Ashram Rd, Ahmedabad, Gujarat 380027', 1, 1, 17),
(6, 'Nalsarovar bird sanctuary', '06:00', '05:30', 'mon-sun', 'nalsarovar.com', 'Nal Sarovar bird sanctuary  Nalsarovar Rd, Nalsarovar, Gujarat,382170', 1, 1, 17),
(7, 'Auto World Vintage Car Museum', '08:00', '09:00', 'mon-sun', '-', 'Dastan Estate, Service Rd, Nikol, Kathwada, Gujarat 382430', 1, 1, 17),
(8, 'Science City', '10:00', '07:30', 'mon-sun', 'sciencecity.gujarat.gov.in', '3FJW+339, Thaltej, Ahmedabad, Gujarat 380060', 1, 1, 17),
(9, 'Taj Skyline', '19:30', '23:00', 'mon-sun', '\r\ntajhotels.com\r\n', 'The Taj Skyline, Sindhu Bhavan Marg, PRL Colony, Thaltej, Ahmedabad, Gujarat 380058', 1, 2, 1),
(10, 'Novotel', '14:00', '12:00', 'mon-sun', 'novotel.accor.com', 'Novotel Iscon Cross Roads, near Wide Angle Cinema, Ahmedabad, Gujarat ', 1, 2, 1),
(11, 'Hyatt Restaurant', '14:00', '12:00', 'mon-sun', 'hyatt.com', 'hyatt Bodakdev Rd, next to Ahmedabad One Mall, Vastrapur, Ahmedabad, Gujarat 380015', 1, 2, 1),
(12, 'Radisson blu', '06:30', '11:00', 'mon-sun', 'radissonhotels.com', 'Radisson blu Near Panchvati Cross, Chimanlal Girdharlal Rd, Ambawadi, Ahmedabad, Gujarat', 1, 2, 1),
(13, 'DoubleTree by Hilton ', '06:00', '11:00', 'mon-sun', 'hilton.com', 'Double Tree by Hilton  Ambli Rd, Vikram Nagar, Ahmedabad, Gujarat 380058', 1, 2, 1),
(14, 'Neelkanth Patang Hotel', '10:00', '12:30', 'mon-sun', '-', 'Patang Hotel Nehru Bridge, Ellisbridge, Ahmedabad, Gujarat 380009', 1, 2, 1),
(15, 'Civil Hospital', '12:00', '12:00', 'mon-sun', 'civilhospitalahd.gujarat.gov.in', 'D Block Asarwa, Haripura, Office of the Medical Superintendent Civil Hospital, Asarwa, Ahmedabad, Gujarat', 1, 3, 1),
(16, 'CIMS Hospital', '12:00', '12:00', 'mon-sun', 'cims.org', 'CIMS Hospital Sola Gam Rd, Science City, Panchamrut Bunglows II, Sola, Ahmedabad, Gujarat 380060', 1, 3, 1),
(17, 'Zydus Hospital', '12:00', '12:00', 'mon-sun', 'zydushospitals.com', 'Zydus Hospital Rd, Sarkhej - Gandhinagar Hwy, near Sola Bridge, Thaltej, Ahmedabad, Gujarat ', 1, 3, 1),
(18, 'KD Hospital', '12:00', '12:00', 'mon-sun', 'kdhospital.co.in', ' Vaishnodevi Circle, Sarkhej - Gandhinagar Hwy, Ahmedabad, Gujarat 382421', 1, 3, 1),
(19, 'HCG Hospital', '12:00', '12:00', 'mon-sun', 'hcghospitals.in', ' HCG Hospital Mithakhali Six Rd, kalyan Society, Maharashtra Society, Ellisbridge, Ahmedabad, Gujarat', 1, 3, 1),
(20, 'Sterling Hospital', '12:00', '12:00', 'mon-sun', 'sterlinghospitals.com', ' Sterling Hospital Rd, Near maharaja agrasen vidhyalaya, L.K Society, Nilmani Society, Memnagar, Ahmedabad\r\n', 1, 3, 1),
(21, 'Gujarat University', '08:00', '06:00', 'mon-sat', 'www.gujaratuniversity.ac.in', 'Gujarat University Navrangpura, Ahmedabad, Gujarat 380009', 1, 4, 1),
(22, 'Nirma University', '08:00', '05:00', 'mon-sat', 'nirmauni.ac.in', 'Nirma University Sarkhej - Gandhinagar Hwy, Gota, Ahmedabad, Gujarat 382481', 1, 4, 7),
(23, 'Lalbhai Dalpatbhai College of Engineering ', '10:30', '06:00', 'mon-sat', 'ldce.ac.in', 'l.d.engineering, 120, Circular Road, University Area, Ahmedabad, Gujarat ', 1, 4, 7),
(24, 'Government Polytechnic For Girls AHMEDABAD', '10:30', '06:00', 'mon-sat', 'ggpahmedabad.in', 'Government Polytechnic For Girls, Opp. Physical Research Laboratory, Ahmedabad,Gujarat', 1, 4, 7),
(25, 'Delhi Public School', '07:30', '03:30', 'mon-sat', 'dpsbopal-ahd.edu.in', 'Delhi Public School Bopal, near Bopal, Railway Crossing, Bopal, Ahmedabad, Gujarat 380058', 1, 4, 7),
(26, 'Anand Niketan', '07:00', '03:00', 'mon-sat', 'anandniketanbhadaj.org', 'Anand Niketan .S.P. Ring Road, Road, nr. Ahmedabad Dental College, Ranchhodpura, Bhadaj, Gujarat ', 1, 4, 7),
(27, 'Shree Balaji Agora Mall', '09:00', '11:30', 'mon-sun', 'sbam.in', 'Shree Balaji Agora Mall Patel Ring Rd, Motera, Ahmedabad, Gujarat 382424', 1, 5, 7),
(28, 'Alpha One Mall', '10:00', '09:30', 'mon-sun', 'alphacorp.in', '261, Sarkari Vasahat Road, Vastrapur, Ahmedabad, Gujarat 380006', 1, 5, 7),
(29, 'PVR Acropolis', '09:30', '11:30', 'mon-sun', 'pvrcinemas.com', ' The Acropolis, Cross Road, Sarkhej - Gandhinagar Highway, A/604, Service Rd, Thaltej, Ahmedabad, Gujarat 380059', 1, 5, 7),
(30, 'Mukta A2 Cinemas', '09:15', '11:00', 'mon-sun', 'muktaa2cinemas.com', 'Mukta A2 Cinemas police Station, 4th Floor, Gulmohar Park Mall, Satellite Rd, opposite Satellite, Ahmedabad, Gujarat 380015', 1, 5, 7),
(31, '100 Acres Club', '10:00', '12:00', 'mon-sun', '100acresclub.com', ' 100 Acres Club Vinchhiya, Sanand - Nalsarovar Rd, Ahmedabad, Gujarat 382220', 1, 5, 7),
(32, 'Rajpath Club ', '12:00', '12:00', 'mon-sun', 'www.rajpathclub.com', ' Rajpath Club Sarkhej Gandhinagar Hwy, Bodakdev, Ahmedabad, Gujarat 380059', 1, 5, 7);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rating`
--

CREATE TABLE `tbl_rating` (
  `r_id` int(11) NOT NULL,
  `rating` varchar(10) DEFAULT NULL,
  `r_status` int(11) NOT NULL,
  `l_id` int(11) DEFAULT NULL,
  `p_id` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_rating`
--

INSERT INTO `tbl_rating` (`r_id`, `rating`, `r_status`, `l_id`, `p_id`, `timestamp`) VALUES
(6, '4', 1, 11, 2, '2022-02-08 06:25:14'),
(8, '4', 1, 12, 2, '2022-02-08 06:25:31'),
(20, '3', 1, 9, 4, '2022-02-07 14:49:30'),
(21, '1', 1, 9, 5, '2022-02-07 14:50:40'),
(22, '2', 1, 10, 4, '2022-02-08 06:26:52'),
(24, '5', 1, 10, 2, '2022-02-07 15:05:27'),
(29, '5', 1, 11, 4, '2022-02-08 14:19:55'),
(31, '3', 1, 11, 5, '2022-02-08 14:25:18'),
(38, '4', 1, 9, 3, '2022-02-09 06:57:02'),
(39, '5', 1, 11, 7, '2022-02-09 11:52:15'),
(40, '4', 1, 17, 2, '2022-03-19 12:21:22'),
(41, '3', 1, 17, 6, '2022-03-21 09:39:08'),
(42, '4', 1, 7, 31, '2022-03-23 17:01:57'),
(43, '4', 1, 7, 32, '2022-03-23 17:02:00'),
(44, '4', 1, 7, 29, '2022-03-23 17:02:07'),
(45, '4', 1, 7, 28, '2022-03-23 17:02:12'),
(46, '4', 1, 7, 21, '2022-03-23 17:02:16'),
(47, '5', 1, 7, 22, '2022-03-23 17:02:19'),
(48, '5', 1, 7, 23, '2022-03-23 17:02:27'),
(49, '4', 1, 7, 24, '2022-03-23 17:02:34'),
(50, '4', 1, 7, 25, '2022-03-23 17:02:39'),
(51, '3', 1, 7, 26, '2022-03-23 17:02:41'),
(52, '4', 1, 7, 15, '2022-03-23 17:02:49'),
(53, '4', 1, 7, 16, '2022-03-23 17:02:51'),
(54, '4', 1, 7, 17, '2022-03-23 17:02:56'),
(55, '4', 1, 7, 18, '2022-03-23 17:02:58'),
(56, '4', 1, 7, 20, '2022-03-23 17:03:03'),
(57, '4', 1, 7, 19, '2022-03-23 17:03:05'),
(58, '5', 1, 7, 9, '2022-03-23 17:03:10'),
(59, '4', 1, 7, 10, '2022-03-23 17:03:13'),
(60, '4', 1, 7, 11, '2022-03-23 17:03:17'),
(61, '4', 1, 7, 12, '2022-03-23 17:03:19'),
(62, '4', 1, 7, 13, '2022-03-23 17:03:23'),
(63, '4', 1, 7, 14, '2022-03-23 17:03:27'),
(64, '4', 1, 7, 1, '2022-03-23 17:03:54'),
(65, '4', 1, 7, 5, '2022-03-23 17:03:57'),
(66, '4', 1, 7, 6, '2022-03-23 17:03:59'),
(67, '4', 1, 7, 2, '2022-03-23 17:04:06'),
(68, '5', 1, 7, 27, '2022-03-24 07:32:16'),
(69, '4', 1, 17, 1, '2022-03-31 03:34:27'),
(70, '4', 1, 21, 1, '2022-04-03 04:49:21'),
(71, '4', 1, 23, 1, '2022-04-06 04:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wishlist`
--

CREATE TABLE `tbl_wishlist` (
  `w_id` int(11) NOT NULL,
  `w_status` varchar(5) DEFAULT NULL,
  `l_id` int(11) DEFAULT NULL,
  `p_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_wishlist`
--

INSERT INTO `tbl_wishlist` (`w_id`, `w_status`, `l_id`, `p_id`) VALUES
(2, '0', 9, 2),
(3, '1', 11, 7),
(8, '0', 17, 2),
(11, '0', 7, 2),
(24, '0', 19, 1),
(27, '0', 17, 1),
(30, '0', 21, 1),
(32, '0', 21, 15),
(35, '0', 23, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `tbl_complain`
--
ALTER TABLE `tbl_complain`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tbl_complain_status`
--
ALTER TABLE `tbl_complain_status`
  ADD PRIMARY KEY (`cs_id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tbl_img`
--
ALTER TABLE `tbl_img`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `tbl_otp`
--
ALTER TABLE `tbl_otp`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `tbl_place`
--
ALTER TABLE `tbl_place`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `tbl_wishlist`
--
ALTER TABLE `tbl_wishlist`
  ADD PRIMARY KEY (`w_id`),
  ADD UNIQUE KEY `l_id` (`l_id`,`p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_complain`
--
ALTER TABLE `tbl_complain`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_complain_status`
--
ALTER TABLE `tbl_complain_status`
  MODIFY `cs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_img`
--
ALTER TABLE `tbl_img`
  MODIFY `i_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `l_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_otp`
--
ALTER TABLE `tbl_otp`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `tbl_place`
--
ALTER TABLE `tbl_place`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `tbl_wishlist`
--
ALTER TABLE `tbl_wishlist`
  MODIFY `w_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
